//
//  Mydate.m
//  Homework02
//
//  Created by 黄炳杰 on 10/17/15.
//  Copyright © 2015 黄炳杰. All rights reserved.
//

#import "Mydate.h"

@implementation Mydate
@synthesize year,month,day,weekNumber;
-(void)setToday
{
    NSDate *dateNow=[NSDate dateWithTimeIntervalSinceNow:0*24*60*60];
    NSCalendar *calendar=[[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *comps=[[NSDateComponents alloc]init];
    NSInteger unitFlags=NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay|NSCalendarUnitWeekday|NSCalendarUnitHour;
    comps=[calendar components:unitFlags fromDate:dateNow];
    weekNumber = [comps weekday];
    day=[comps day];
    year=[comps year];
    month=[comps month];
}
-(void)setDate:(int)y :(int)m :(int) d
{
    NSDateComponents *comp=[[NSDateComponents alloc]init];
    [comp setMonth:m];
    [comp setDay:d];
    [comp setYear:y];
    NSCalendar *myCal=[[NSCalendar alloc]initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *myd=[myCal dateFromComponents:comp];
    
    //NSDate *dateNew=[NSDate dateWithTimeIntervalSinceNow:9*60*60];
    NSDate *dateNew=[NSDate dateWithTimeInterval:9*60*60 sinceDate:myd];
    NSInteger unitFlags=NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay|NSCalendarUnitWeekday|NSCalendarUnitHour;
    comp=[myCal components:unitFlags fromDate:dateNew];
    weekNumber = [comp weekday];
    day=[comp day];
    year=[comp year];
    month=[comp month];
}
-(void)printThisMonth
{
    switch (month) {
        case 1:
            printf("    January");
            break;
        case 2:
            printf("    February");
            break;
        case 3:
            printf("    March");
            break;
        case 4:
            printf("    April");
            break;
        case 5:
            printf("    May");
            break;
        case 6:
            printf("    June");
            break;
        case 7:
            printf("    July");
            break;
        case 8:
            printf("    August");
            break;
        case 9:
            printf("    September");
            break;
        case 10:
            printf("    October");
            break;
        case 11:
            printf("    November");
            break;
        case 12:
            printf("    December");
            break;
        default:
            break;
    }
    printf(" %ld\n",year);
    printf("Su Mo To We Th Fr Sa\n");
    printf(" ");
    for (int i=1;i<weekNumber; i++) {
        printf("   ");
    }
    
    int num=0;
    for (; num<(7-weekNumber+1); num++) {
        printf("%d  ",num+1);
    }
    printf("\n");                           //第一行打印完毕
    
    int hang=0;
    int monDay=[self getMonDay:self.year:self.month];
    for (; num<monDay; num++) {
        if ((num+1)/10>=1) {
            printf("%d ",num+1);
        }
        else printf(" %d ",num+1);
        if ((++hang)%7==0) {
            printf("\n");
        }
    }
    printf("\n");
}
-(int)getMonDay:(NSInteger)yeaNum:(NSInteger)monNun
{
    switch (monNun) {
        case 1:
            return 31;
        case 2:
            if ((yeaNum%4==0&&yeaNum%100!=0)||yeaNum%400==0) {
                return 29;
            }
            else return 28;
        case 3:
            return 31;
        case 4:
            return 30;
        case 5:
            return 31;
        case 6:
            return 30;
        case 7:
            return 31;
        case 8:
            return 31;
        case 9:
            return 30;
        case 10:
            return 31;
        case 11:
            return 30;
        case 12:
            return 31;
    }
    return 0;
}
-(void)printYear:(NSInteger)yearNum
{
    int weekNum[12]={0};                            //记录起始的星期数
    int dayNum[12]={0};                             //每个月打印到哪里了
    int monDay[12]={0};                             //每个月总共的天数
    for (int i=0; i<12; i++) {
        monDay[i]=[self getMonDay:yearNum:(i+1)];
    }
    for (int i=0; i<12; i++) {
        [self setDate:(int)yearNum :i+1 :1];
        weekNum[i]=(int)self.weekNumber;
    }
    //-------------------------------------------------打印1~3月份
    printf("                             %li\n\n",yearNum);
    printf("      January               February               March\n");
    printf("Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa\n");
    for (int i=0; i<3; i++) {//第一行特殊，先打印第一行的空格
        for (int j=1;j<weekNum[i]; j++) {
            printf("   ");
        }
        for(;dayNum[i]<(7-weekNum[i]+1);dayNum[i]++)
        {
            printf(" %d ",dayNum[i]+1);
        }
        printf(" ");
    }
    printf("\n");
    
    //打印余下行数
    while (dayNum[0]<monDay[0] || dayNum[1]<monDay[1] || dayNum[2] <monDay[2]) {
        for (int i=0; i<3; i++) {
            for(int j=0;j<7;j++)
            {
                if (dayNum[i]<monDay[i]) {//还未打印完
                    if((dayNum[i]+1)/10>=1)//如果是10以上的日期
                    {
                        printf("%d ",dayNum[i]+1);
                    }
                    else
                        printf(" %d ",dayNum[i]+1);
                    dayNum[i]++;
                }
                else
                    printf("   ");//打印完了就输出空格配合其他月份
            }
            printf(" ");//每两个月之间有两个空格
        }
        printf("\n");
    }
    printf("\n");
    //-------------------------------------------------打印1~3月份完毕
    printf("       April                  May                   June\n");
    printf("Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa\n");
    //-------------------------------------------------打印4~6月份
    for (int i=3; i<6; i++) {//第一行特殊，先打印第一行的空格
        for (int j=1;j<weekNum[i]; j++) {
            printf("   ");
        }
        for(;dayNum[i]<(7-weekNum[i]+1);dayNum[i]++)
        {
            printf(" %d ",dayNum[i]+1);
        }
        printf(" ");
    }
    printf("\n");
    
    //打印余下行数
    while (dayNum[3]<monDay[3] || dayNum[4]<monDay[4] || dayNum[5] <monDay[5]) {
        for (int i=3; i<6; i++) {
            for(int j=0;j<7;j++)
            {
                if (dayNum[i]<monDay[i]) {//还未打印完
                    if((dayNum[i]+1)/10>=1)//如果是10以上的日期
                    {
                        printf("%d ",dayNum[i]+1);
                    }
                    else
                        printf(" %d ",dayNum[i]+1);
                    dayNum[i]++;
                }
                else
                    printf("   ");//打印完了就输出空格配合其他月份
            }
            printf(" ");//每两个月之间有两个空格
        }
        printf("\n");
    }
    printf("\n");
    //-------------------------------------------------打印4~6月份完毕
    printf("        July                 August              September\n");
    printf("Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa\n");
    //-------------------------------------------------打印7~9月份
    for (int i=6; i<9; i++) {//第一行特殊，先打印第一行的空格
        for (int j=1;j<weekNum[i]; j++) {
            printf("   ");
        }
        for(;dayNum[i]<(7-weekNum[i]+1);dayNum[i]++)
        {
            printf(" %d ",dayNum[i]+1);
        }
        printf(" ");
    }
    printf("\n");
    
    //打印余下行数
    while (dayNum[6]<monDay[6] || dayNum[7]<monDay[7] || dayNum[8] <monDay[8]) {
        for (int i=6; i<9; i++) {
            for(int j=0;j<7;j++)
            {
                if (dayNum[i]<monDay[i]) {//还未打印完
                    if((dayNum[i]+1)/10>=1)//如果是10以上的日期
                    {
                        printf("%d ",dayNum[i]+1);
                    }
                    else
                        printf(" %d ",dayNum[i]+1);
                    dayNum[i]++;
                }
                else
                    printf("   ");//打印完了就输出空格配合其他月份
            }
            printf(" ");//每两个月之间有两个空格
        }
        printf("\n");
    }
    printf("\n");
    //-------------------------------------------------打印7~9月份完毕
    printf("      October               November              December\n");
    printf("Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa  Su Mo Tu We Th Fr Sa\n");
    //-------------------------------------------------打印10~12月份
    for (int i=9; i<12; i++) {//第一行特殊，先打印第一行的空格
        for (int j=1;j<weekNum[i]; j++) {
            printf("   ");
        }
        for(;dayNum[i]<(7-weekNum[i]+1);dayNum[i]++)
        {
            printf(" %d ",dayNum[i]+1);
        }
        printf(" ");
    }
    printf("\n");
    
    //打印余下行数
    while (dayNum[9]<monDay[9] || dayNum[10]<monDay[10] || dayNum[11] <monDay[11]) {
        for (int i=9; i<12; i++) {
            for(int j=0;j<7;j++)
            {
                if (dayNum[i]<monDay[i]) {//还未打印完
                    if((dayNum[i]+1)/10>=1)//如果是10以上的日期
                    {
                        printf("%d ",dayNum[i]+1);
                    }
                    else
                        printf(" %d ",dayNum[i]+1);
                    dayNum[i]++;
                }
                else
                    printf("   ");//打印完了就输出空格配合其他月份
            }
            printf(" ");//每两个月之间有两个空格
        }
        printf("\n");
    }
    //-------------------------------------------------打印10~12月份完毕
    printf("\n");
}
@end
