//
//  Mydate.h
//  Homework02
//
//  Created by 黄炳杰 on 10/17/15.
//  Copyright © 2015 黄炳杰. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Mydate : NSObject
@property long weekNumber;
@property long day;
@property long year;
@property long month;
-(void)setToday;
-(void)setDate:(int)y :(int)m :(int) d;
-(void)printThisMonth;
-(int)getMonDay:(NSInteger)yeaNum:(NSInteger)monNun;
-(void)printYear:(NSInteger)yearNum;
@end
