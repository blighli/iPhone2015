//
//  main.m
//  Homework02
//
//  Created by 黄炳杰 on 10/16/15.
//  Copyright © 2015 黄炳杰. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Mydate.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        
        
        // 说明：程序只能查询公元0~5000的日历
        
        
        Mydate *mydate=[[Mydate alloc]init];
        mydate.setToday;
        
        NSString *num2Str=[NSString alloc];
        NSString *num3Str=[NSString alloc];
        NSInteger num2Int = 0;
        NSInteger num3Int=0;

        if(argc>2  && strcmp(argv[2], "-m"))
        {
            num2Str=[num2Str initWithCString:argv[2] encoding:NSUTF8StringEncoding];
            num2Int=[num2Str intValue];
        }
        if(num2Int>=5000 || num2Int < 0)
        {
            NSLog(@"日期信息输入不符合要求");
            return 0;
        }
        
        switch (argc) {
            case 1:
                NSLog(@"日期信息输入不符合要求");
                return 0;
            case 2:
                if (strcmp(argv[1], "cal")==0) {
                    [mydate setDate:(int)mydate.year :(int)mydate.month :1];
                    mydate.printThisMonth;
                }
                else
                {
                    NSLog(@"日期信息输入不符合要求");
                    return 0;
                }
                return 0;
            case 3:
                [mydate printYear:num2Int];
                return 0;
            case 4:
                if (strcmp(argv[2], "-m")==0) {
                    num3Str=[num3Str initWithCString:argv[3] encoding:NSUTF8StringEncoding];
                    num3Int=[num3Str intValue];
                    if (num3Int>12 || num3Int<1) {
                        NSLog(@"月份信息不符合要求");
                        return 0;
                    }
                    [mydate setDate:(int)mydate.year :(int)num3Int :1];
                    mydate.printThisMonth;
                }
                else
                {
                    num3Str=[num3Str initWithCString:argv[3] encoding:NSUTF8StringEncoding];
                    num3Int=[num3Str intValue];
                    if (num2Int>12 || num2Int<1 || num3Int<0|| num3Int>5000) {
                        NSLog(@"日期信息输入不符合要求");
                        return 0;
                    }
                    [mydate setDate:(int)num3Int :(int)num2Int :1];
                    mydate.printThisMonth;
                }
                return 0;
            default:
                NSLog(@"日期信息输入不符合要求");
                return 0;
        }
    }
}
