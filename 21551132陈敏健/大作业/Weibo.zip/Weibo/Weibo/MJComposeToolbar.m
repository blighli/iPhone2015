//
//  MJComposeToolbar.m
//  Weibo
//
//  Created by 敏少eclipse on 15/9/3.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJComposeToolbar.h"
#import "UIImage+MJ.h"
@implementation MJComposeToolbar

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        //设置背景
        self.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageWithName:@"compose_toolbar_background"]];
        
        //添加按钮
        [self addBtnWithIcon:@"compose_camerabutton_background" highIcon:@"compose_camerabutton_background_highlighted" tag:MJComposeToolbarBtnTypeCamera];
        [self addBtnWithIcon:@"compose_toolbar_picture" highIcon:@"compose_toolbar_picture_highlighted" tag:MJComposeToolbarBtnTypePicture];
        [self addBtnWithIcon:@"compose_mentionbutton_background" highIcon:@"compose_mentionbutton_background_highlighted" tag:MJComposeToolbarBtnTypeMention];
        [self addBtnWithIcon:@"compose_trendbutton_background" highIcon:@"compose_trendbutton_background_highlighted" tag:MJComposeToolbarBtnTypeTrend];
        [self addBtnWithIcon:@"compose_emoticonbutton_background" highIcon:@"compose_emoticonbutton_background_highlighted" tag:MJComposeToolbarBtnTypeEmotion];
    }
    return self;
}


-(void)addBtnWithIcon:(NSString *)icon highIcon:(NSString *)highIcon tag:(int)tag
{
    UIButton *button=[[UIButton alloc] init];
    button.tag=tag;
    [button addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
    [button setImage:[UIImage imageWithName:icon] forState:UIControlStateNormal];
    [button setImage:[UIImage imageWithName:highIcon] forState:UIControlStateHighlighted];
    [self addSubview:button];
}

-(void)btnClick:(UIButton *)btn
{
    if ([self.delegate respondsToSelector:@selector(composeToolbar:didClickedButton:)]) {
        [self.delegate composeToolbar:self didClickedButton:btn.tag];
    }
}


-(void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat btnY=0;
    CGFloat btnW=self.frame.size.width/self.subviews.count;
    CGFloat btnH=self.frame.size.height;
    for (int i=0; i<self.subviews.count; i++) {
        UIButton *btn=self.subviews[i];
        CGFloat btnX=btnW*i;
        btn.frame=CGRectMake(btnX,btnY, btnW, btnH);
    }
}

@end
