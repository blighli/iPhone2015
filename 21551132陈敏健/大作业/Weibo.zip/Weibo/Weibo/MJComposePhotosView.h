//
//  MJComposePhotosView.h
//  Weibo
//
//  Created by 敏少eclipse on 15/9/3.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MJComposePhotosView : UIView

-(NSArray *)totalImages;

//添加一张新的图片
-(void)addImage:(UIImage *)image;
@end
