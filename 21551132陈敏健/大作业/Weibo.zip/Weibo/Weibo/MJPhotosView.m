//
//  MJPhotosView.m
//  Weibo
//
//  Created by 敏少eclipse on 15/9/1.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "UIImageView+WebCache.h"
#import "SDPhotoBrowser.h"
#import "MJPhotosView.h"
#import "MJPhoto.h"
#import "MJPhotoView.h"
#define MJPhotoW 70
#define MJPhotoH 70
#define MJPhotoMargin 10

@interface MJPhotosView()<SDPhotoBrowserDelegate>

@end

@implementation MJPhotosView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        //先初始化9个控件，之后根据具体情况决定
        for (int i=0; i<9; i++) {
            MJPhotoView *photoView=[[MJPhotoView alloc] init];
            photoView.userInteractionEnabled=YES;
            photoView.tag=i;
            [photoView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(photoTap:)]];
            [self addSubview:photoView];
        }
    }
    return self;
}

-(void)photoTap:(UITapGestureRecognizer *)recognizer
{
    NSLog(@"tap-%d",recognizer.view.tag);
    
    //使用图片浏览器控件
    SDPhotoBrowser *browser=[[SDPhotoBrowser alloc] init];
    browser.sourceImagesContainerView=self;// 原图的父控件
    browser.imageCount=self.photos.count;// 图片总数
    browser.currentImageIndex=recognizer.view.tag;
    browser.delegate=self;
    [browser show];
    
}

//以下两个函数为代理函数
-(UIImage *)photoBrowser:(SDPhotoBrowser *)browser placeholderImageForIndex:(NSInteger)index
{
    //此句报错
    //return [self.subviews[index] currentImage];
    
    return [self.subviews[index] image];
}

-(NSURL *)photoBrowser:(SDPhotoBrowser *)browser highQualityImageURLForIndex:(NSInteger)index
{
    NSString *urlStr = [[self.photos[index] thumbnail_pic] stringByReplacingOccurrencesOfString:@"thumbnail" withString:@"bmiddle"];
    return [NSURL URLWithString:urlStr];
}


-(void)setPhotos:(NSArray *)photos
{
    _photos=photos;
    
    for (int i=0; i<self.subviews.count; i++) {
        //取出对应的ImageView
        MJPhotoView *photoView=self.subviews[i];
        //判断这个imageView是否需要
        if(i<photos.count)
        {
            //显示图片
            photoView.hidden=NO;
            
            //传递数据模型
            photoView.photo=photos[i];
            
            //设置frame
            int maxColumn=(photos.count==4)?2:3;
            int col=i%maxColumn;
            int row=i/maxColumn;
            CGFloat photoX=col*(MJPhotoW+MJPhotoMargin);
            CGFloat photoY=row*(MJPhotoH+MJPhotoMargin);
            photoView.frame=CGRectMake(photoX, photoY, MJPhotoW, MJPhotoH);
            
            
        }else{
            //隐藏图片
            photoView.hidden=YES;
        }
        
    }
}

+(CGSize)photosViewSizeWithPhotosCount:(int)count
{
    //最大列数
    int maxColumn=(count==4)?2:3;
    //总行数
    int row=(count+maxColumn-1)/maxColumn;
    //总列数
    int col=(count<maxColumn)?count:maxColumn;
    //总宽度
    CGFloat photosW=col*MJPhotoW+(col-1)*MJPhotoMargin;
    //总高度
    CGFloat photosH=row*MJPhotoH+(row-1)*MJPhotoMargin;
    
    return CGSizeMake(photosW, photosH);
}

@end
