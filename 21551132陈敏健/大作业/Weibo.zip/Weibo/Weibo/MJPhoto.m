//
//  MJPhoto.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/31.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJPhoto.h"

@implementation MJPhoto

@end
