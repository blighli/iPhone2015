//
//  MJCommon.h
//  Weibo
//
//  Created by 敏少eclipse on 15/9/7.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#ifndef Weibo_MJCommon_h
#define Weibo_MJCommon_h

//账号信息
#define MJAppKey @"2448241402"
#define MJAppSecret @"5252049bffc10fbf34adf7075c850b39"
#define MJRedirectURI @"http://www.baidu.com"

//获得RGB颜色
#define MJColor(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1.0]

//自定义log
#ifdef DEBUG
#define MJLog(...) NSLog(__VA_ARGS__)
#else
#define MJLog(...)
#endif

//微博cell上面的属性
//昵称字体
#define MJStatusNameFont [UIFont systemFontOfSize:15]
//时间的字体
#define MJStatusTimeFont [UIFont systemFontOfSize:12]
//来源的字体
#define MJStatusSourceFont MJStatusTimeFont
//正文的字体
#define MJStatusContentFont [UIFont systemFontOfSize:13]

//被转发微博昵称字体
#define MJRetweetedStatusNameFont MJStatusNameFont
//被转发微博正文的字体
#define MJRetweetedStatusContentFont MJStatusContentFont

//边框宽度
#define MJStatusCellBorder 5

//表格的边框宽度
#define MJStatusTableBorder 5



#endif
