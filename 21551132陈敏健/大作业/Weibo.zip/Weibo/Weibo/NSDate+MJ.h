//
//  NSDate+MJ.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/30.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (MJ)
//是否为今天
-(BOOL)isToday;
//是否为昨天
-(BOOL)isYesterday;
//是否为今年
-(BOOL)isThisYear;
//返回时间差距
-(NSDateComponents *)deltaWithNow;

//返回只有年月日的时间
-(NSDate *)dateWithYMD;
@end
