//
//  MJStatus.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/29.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import <Foundation/Foundation.h>
#import "MJUser.h"
@interface MJStatus : NSObject
//微博的ID
@property (nonatomic,copy) NSString * idstr;
//微博的内容
@property (nonatomic,copy) NSString * text;
//微博的时间
@property (nonatomic,copy) NSString * created_at;
//微博的来源
@property (nonatomic,copy) NSString * source;
//微博的转发数
@property (nonatomic,assign) int reposts_count;
//微博的回复数
@property (nonatomic,assign) int comments_count;
//点赞数
@property (nonatomic,assign) int attitudes_count;
//微博作者
@property (nonatomic,strong) MJUser * user;
//微博的单张配图
//@property (nonatomic,copy) NSString * thumbnail_pic;
//微博的多张配图
@property (nonatomic,strong) NSArray * pic_urls;
//被转发的微博
@property (nonatomic,strong) MJStatus * retweeted_status;
@end
