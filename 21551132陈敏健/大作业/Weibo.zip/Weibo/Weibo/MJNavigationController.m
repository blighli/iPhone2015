//
//  MJNavigationController.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/27.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJNavigationController.h"
#import "UIImage+MJ.h"
#define iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >=7.0)
@interface MJNavigationController ()

@end

@implementation MJNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

//设置导航栏主题
+(void)initialize
{
    //设置导航栏主题
    [self setupNavBarTheme];
    
    //设置导航栏按钮主题
    [self setupBarButtonItemTheme];
}

//设置导航栏主题
+(void)setupNavBarTheme
{
    UINavigationBar * navBar=[UINavigationBar appearance];
    if(!iOS7)
    {
        [navBar setBackgroundImage:[UIImage imageWithName:@"navigationbar_background"] forBarMetrics:UIBarMetricsDefault];
        [UIApplication sharedApplication].statusBarStyle=UIStatusBarStyleDefault;
    }
    NSMutableDictionary *textAttrs=[NSMutableDictionary dictionary];
    textAttrs[UITextAttributeTextColor]=[UIColor blackColor];
    textAttrs[UITextAttributeTextShadowOffset]=[NSValue valueWithUIOffset:UIOffsetZero];
    textAttrs[UITextAttributeFont]=[UIFont boldSystemFontOfSize:19];
    [navBar setTitleTextAttributes:textAttrs];
}

+(void)setupBarButtonItemTheme
{
    UIBarButtonItem *item=[UIBarButtonItem appearance];
    
    if(!iOS7)
    {
    [item setBackgroundImage:[UIImage imageWithName:@"navigationbar_button_background"] forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
    [item setBackgroundImage:[UIImage imageWithName:@"navigationbar_button_background_pushed"] forState:UIControlStateHighlighted barMetrics:UIBarMetricsDefault];
    [item setBackgroundImage:[UIImage imageWithName:@"navigationbar_button_background_disable"] forState:UIControlStateDisabled barMetrics:UIBarMetricsDefault];
    }
    //设置文字属性
    NSMutableDictionary *textAttrs=[NSMutableDictionary dictionary];
    textAttrs[UITextAttributeTextColor]=iOS7?[UIColor orangeColor]:[UIColor grayColor];
    textAttrs[UITextAttributeTextShadowOffset]=[NSValue valueWithUIOffset:UIOffsetZero];
    textAttrs[UITextAttributeFont]=[UIFont systemFontOfSize:iOS7?15:12];
    [item setTitleTextAttributes:textAttrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:textAttrs forState:UIControlStateHighlighted];
    
    NSMutableDictionary *disableTextAttrs=[NSMutableDictionary dictionary];
    disableTextAttrs[UITextAttributeTextColor]=[UIColor grayColor];
    [item setTitleTextAttributes:disableTextAttrs forState:UIControlStateDisabled];
}

-(void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    if(self.viewControllers.count>0)
    {
    viewController.hidesBottomBarWhenPushed=YES;
    }
    [super pushViewController:viewController animated:animated];
}

@end
