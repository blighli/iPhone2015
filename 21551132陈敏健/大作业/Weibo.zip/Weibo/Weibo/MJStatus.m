//
//  MJStatus.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/29.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJPhoto.h"
#import "MJStatus.h"
#import "NSObject+MJProperty.h"
#import "NSDate+MJ.h"
@implementation MJStatus

+(void)initialize
{
    [MJStatus setupObjectClassInArray:^NSDictionary *{
        return @{
                 @"pic_urls" : @"MJPhoto"
                 // @"pic_urls" : [MJPhoto class]
                 };
    }];
}

//由于需要更新内容，所以使用get方法
-(NSString *)created_at
{
    NSDateFormatter *fmt=[[NSDateFormatter alloc] init];
    fmt.dateFormat=@"EEE MMM dd HH:mm:ss Z yyyy";
    //表明格式的地域,真机上使用需要这一句
    fmt.locale=[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"];
    NSDate *createdDate=[fmt dateFromString:_created_at];
    if(createdDate.isToday)
    {
        if(createdDate.deltaWithNow.hour>=1)
        {
            return [NSString stringWithFormat:@"%ld小时前", createdDate.deltaWithNow.hour];
        }
        else if(createdDate.deltaWithNow.minute>=1)
        {
            return [NSString stringWithFormat:@"%ld分钟前", createdDate.deltaWithNow.minute];
        }else{
            return @"刚刚";
        }
    }else if(createdDate.isYesterday)
    {
        fmt.dateFormat=@"昨天 HH:mm";
        return [fmt stringFromDate:createdDate];
    }else if(createdDate.isThisYear)
    {
        fmt.dateFormat=@"MM-dd HH:mm";
        return [fmt stringFromDate:createdDate];
    }else{
        fmt.dateFormat=@"yyyy-MM-dd HH:mm";
        return [fmt stringFromDate:createdDate];
    }
}


//由于内容只需要设置一次，所以使用set方法
-(void)setSource:(NSString *)source
{
    if(source==nil||[source isEqualToString:@""])
    {
        _source=@"";
        return;
    }
    
    int startLoc=[source rangeOfString:@">"].location+1;
    int length=[source rangeOfString:@"</"].location-startLoc;
    source=[source substringWithRange:NSMakeRange(startLoc, length)];
    _source=[NSString stringWithFormat:@"来自%@",source];
}

@end
