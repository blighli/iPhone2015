//
//  MJHomeViewController.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/25.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJRefresh.h"
#import "MJUser.h"
#import "MJStatusFrame.h"
#import "MJStatusCell.h"
#import "MJStatus.h"
#import "MJAccountTools.h"
#import "NSObject+MJKeyValue.h"
#import "UIImageView+WebCache.h"
#import "MJExtension.h"
#import "AFNetworking.h"
#import "MJHomeViewController.h"
#import "UIImage+MJ.h"
#import "UIBarButtonItem+MJ.h"
#import "MJAccount.h"
#import "MJTitleButton.h"
@interface MJHomeViewController ()
@property (nonatomic,strong) NSMutableArray * statusFrames;
@property (nonatomic,weak) MJTitleButton * titleBtn;
@end

@implementation MJHomeViewController

-(NSMutableArray *)statusFrames
{
    if (_statusFrames==nil) {
        _statusFrames=[NSMutableArray array];
    }
    return _statusFrames;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //添加刷新控件，并第一次获取微博数据
    [self setupRefreshView];
    
    [self setNavBar];
    
    //获取并设置用户数据
    [self setupUserData];
    
    //[self setupStatusData];
}

-(void)setupRefreshView
{
    //添加控件，添加点击事件
    UIRefreshControl *refreshControl=[[UIRefreshControl alloc] init];
    [refreshControl addTarget:self action:@selector(refreshControlStateChange:) forControlEvents:UIControlEventValueChanged];
    [self.tableView addSubview:refreshControl];
    
    //让第一次登录时，有刷新效果，不会触发事件
    [refreshControl beginRefreshing];
   
    //手动触发，获取微博数据
    [self refreshControlStateChange:refreshControl];
    
    //上拉控件
    self.tableView.footer=[MJRefreshAutoNormalFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadingMoreOldStatuses)];
}

-(void)loadingMoreOldStatuses
{
    //创建请求管理类
    AFHTTPRequestOperationManager *mgr=[AFHTTPRequestOperationManager manager];
    
    //封装请求参数
    NSMutableDictionary *params=[NSMutableDictionary dictionary];
    params[@"access_token"]=[MJAccountTools account].access_token;
    if(self.statusFrames.count)
    {
        MJStatusFrame *statusFrame=self.statusFrames.lastObject;
        //加载ID比max_i小的微博
        long long maxId=[statusFrame.status.idstr longLongValue]-1;
        params[@"max_id"]=@(maxId);
    }
    
    //发生请求
    [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"%@",[responseObject class]);
        NSLog(@"%@",responseObject);
        
        NSArray * statusArray=[MJStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        
        NSMutableArray *statusFrameArray=[NSMutableArray array];
        for(MJStatus *status in statusArray)
        {
            MJStatusFrame * statusFrame=[[MJStatusFrame alloc] init];
            statusFrame.status=status;
            [statusFrameArray addObject:statusFrame];
        }
        
        [self.statusFrames addObjectsFromArray:statusFrameArray];
        
        [self.tableView reloadData];
        
        //显示最新微博数量
        [self showNewStatusCount:statusFrameArray.count];
        
        //加载后隐藏
        [self.tableView.footer endRefreshing];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        [self.tableView.footer endRefreshing];
    }];
}

-(void)refreshControlStateChange:(UIRefreshControl *)refreshControl
{
    //创建请求管理类
    AFHTTPRequestOperationManager *mgr=[AFHTTPRequestOperationManager manager];
    
    //说明服务器返回的是JSON数据,默认就是JSON,所以不需要这句
    //mgr.responseSerializer=[AFJSONResponseSerializer serializer];
    
    
    //封装请求参数
    NSMutableDictionary *params=[NSMutableDictionary dictionary];
    params[@"access_token"]=[MJAccountTools account].access_token;
    if(self.statusFrames.count)
    {
        MJStatusFrame *statusFrame=self.statusFrames[0];
        //加载ID比since_id大的微博
        params[@"since_id"]=statusFrame.status.idstr;
    }
    
    //发生请求
    [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"%@",[responseObject class]);
        NSLog(@"%@",responseObject);
        
        NSArray * statusArray=[MJStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        
        NSMutableArray *statusFrameArray=[NSMutableArray array];
        for(MJStatus *status in statusArray)
        {
            MJStatusFrame * statusFrame=[[MJStatusFrame alloc] init];
            statusFrame.status=status;
            [statusFrameArray addObject:statusFrame];
        }
        
        NSMutableArray *tempArray=[NSMutableArray array];
        [tempArray addObjectsFromArray:statusFrameArray];
        [tempArray addObjectsFromArray:self.statusFrames];
        
        self.statusFrames=tempArray;
        
        [self.tableView reloadData];
        
        //刷新控件停止刷新
        [refreshControl endRefreshing];
        
        //显示最新微博数量
        [self showNewStatusCount:statusFrameArray.count];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        [refreshControl endRefreshing];
    }];
}

//显示最新微博的数量
-(void)showNewStatusCount:(int)count
{
    UIButton *btn=[[UIButton alloc] init];
    //将按钮加在导航栏控制器上，并在导航栏后面
    [self.navigationController.view insertSubview:btn belowSubview:self.navigationController.navigationBar];
    
    //设置文字和图片
    btn.userInteractionEnabled=NO;
    [btn setBackgroundImage:[UIImage resizedImageWithName:@"timeline_new_status_background"] forState:UIControlStateNormal];
    if (count) {
        NSString *title=[NSString stringWithFormat:@"共有%d条新的微博",count];
        [btn setTitle:title forState:UIControlStateNormal];
    }else{
        [btn setTitle:@"没有新的微博" forState:UIControlStateNormal];
    }
    
    //设置按钮的初始frame
    CGFloat btnX=0;
    CGFloat btnH=30;
    CGFloat btnY=64-btnH;
    CGFloat btnW=self.view.frame.size.width;
    btn.frame=CGRectMake(btnX, btnY, btnW, btnH);
    
    //通过动画移动按钮
    [UIView animateWithDuration:0.7 animations:^{
        btn.transform=CGAffineTransformMakeTranslation(0, btnH+1);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.7 delay:1.0 options:UIViewAnimationOptionCurveLinear animations:^{
            //清空transform
            btn.transform=CGAffineTransformIdentity;
        } completion:^(BOOL finished) {
            [btn removeFromSuperview];
        }];
    }];
}

//被refreshControlStateChange:代替
-(void)setupStatusData
{
    //创建请求管理类
    AFHTTPRequestOperationManager *mgr=[AFHTTPRequestOperationManager manager];
    
    //说明服务器返回的是JSON数据,默认就是JSON,所以不需要这句
    //mgr.responseSerializer=[AFJSONResponseSerializer serializer];
    
    
    //封装请求参数
    NSMutableDictionary *params=[NSMutableDictionary dictionary];
    params[@"access_token"]=[MJAccountTools account].access_token;
    
    //发生请求
    [mgr GET:@"https://api.weibo.com/2/statuses/home_timeline.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"%@",[responseObject class]);
        NSLog(@"%@",responseObject);
        
        NSArray * statusArray=[MJStatus objectArrayWithKeyValuesArray:responseObject[@"statuses"]];
        
        NSMutableArray *statusFrameArray=[NSMutableArray array];
        for(MJStatus *status in statusArray)
        {
            MJStatusFrame * statusFrame=[[MJStatusFrame alloc] init];
            statusFrame.status=status;
            [statusFrameArray addObject:statusFrame];
        }
        
        self.statusFrames=statusFrameArray;
        
        [self.tableView reloadData];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
    }];

}

-(void)setNavBar
{
    //左边按钮
    self.navigationItem.leftBarButtonItem=[UIBarButtonItem itemWithIcon:@"navigationbar_friendsearch" highIcon:@"navigationbar_friendsearch_highlighted" target:self action:@selector(findFriend)];
    
    //右边按钮
    self.navigationItem.rightBarButtonItem=[UIBarButtonItem itemWithIcon:@"navigationbar_pop" highIcon:@"navigationbar_pop_highlighted" target:self action:@selector(pop)];
    
    //中间按钮
    MJTitleButton *titleBtn=[[MJTitleButton alloc] init];
    [titleBtn setImage:[UIImage imageWithName:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
    //宽度设置成0的原因：重写了方法，设置内容时会设置宽度
    titleBtn.frame=CGRectMake(0, 0, 0, 30);
    
    //获取昵称
    MJAccount *account=[MJAccountTools account];
    if(account.name)
    {
        //设置内容，并自动设置宽度
        [titleBtn setTitle:account.name forState:UIControlStateNormal];
    }else{
        [titleBtn setTitle:@"首页" forState:UIControlStateNormal];
    }
    
    [titleBtn addTarget:self action:@selector(titleClick:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.titleView=titleBtn;
    self.titleBtn=titleBtn;
    
    //设置背景颜色
    self.tableView.backgroundColor=[UIColor colorWithRed:226/255.0 green:226/255.0 blue:226/255.0 alpha:1];
    //设置上下空白,不注释会出现bug
    //self.tableView.contentInset=UIEdgeInsetsMake(MJStatusTableBorder, 0, MJStatusTableBorder, 0);
    //设置分割线
    self.tableView.separatorStyle=UITableViewCellSeparatorStyleNone;
}


-(void)setupUserData
{
    //创建请求管理类
    AFHTTPRequestOperationManager *mgr=[AFHTTPRequestOperationManager manager];
    
    //说明服务器返回的是JSON数据,默认就是JSON,所以不需要这句
    //mgr.responseSerializer=[AFJSONResponseSerializer serializer];
    
    
    //封装请求参数
    NSMutableDictionary *params=[NSMutableDictionary dictionary];
    params[@"access_token"]=[MJAccountTools account].access_token;
    params[@"uid"]=@([MJAccountTools account].uid);
    
    //发生请求
    [mgr GET:@"https://api.weibo.com/2/users/show.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"%@",[responseObject class]);
        NSLog(@"%@",responseObject);
        MJUser *user=[MJUser objectWithKeyValues:responseObject];
        //设置按钮的内容，重写了方法，会设置按钮宽度
        [self.titleBtn setTitle:user.name forState:UIControlStateNormal];
        //保存昵称
        MJAccount *account=[MJAccountTools account];
        account.name=user.name;
        [MJAccountTools saveAccount:account];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
    }];

}

-(void)titleClick:(MJTitleButton *)titleButton
{
    if(titleButton.tag==0)
    {
        [titleButton setImage:[UIImage imageWithName:@"navigationbar_arrow_up"] forState:UIControlStateNormal];
        titleButton.tag=-1;
    }
    else
    {
        [titleButton setImage:[UIImage imageWithName:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
        titleButton.tag=0;
    }
    
    //无法使用
//    if(titleButton.currentImage==[UIImage imageWithName:@"navigationbar_arrow_down"])
//    {
//        [titleButton setImage:[UIImage imageWithName:@"navigationbar_arrow_up"] forState:UIControlStateNormal];
//    }
//    else
//    {
//        [titleButton setImage:[UIImage imageWithName:@"navigationbar_arrow_down"] forState:UIControlStateNormal];
//    }
}

-(void)findFriend
{
    
}

-(void)pop
{
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.statusFrames.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //创建cell
    MJStatusCell *cell=[MJStatusCell cellWithTableView:tableView];
    //设置cell
    MJStatusFrame *statusFrame=self.statusFrames[indexPath.row];
    cell.statusFrame=statusFrame;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UIViewController *vc=[[UIViewController alloc] init];
    vc.view.backgroundColor=[UIColor redColor];
    [self.navigationController pushViewController:vc animated:YES];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    MJStatusFrame *statusFrame=self.statusFrames[indexPath.row];
    return statusFrame.cellHeight;
}

@end
