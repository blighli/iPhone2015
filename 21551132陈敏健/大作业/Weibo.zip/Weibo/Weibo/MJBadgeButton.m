//
//  MJBadgeButton.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/26.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJBadgeButton.h"
#import "UIImage+MJ.h"
@implementation MJBadgeButton

//计算文字尺寸
-(CGSize)sizeWithText:(NSString *)text font:(UIFont *)font maxSize:(CGSize)maxSize
{
    NSDictionary *attrs=@{NSFontAttributeName:font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}


- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.hidden=YES;
        self.userInteractionEnabled=NO;
        [self setBackgroundImage:[UIImage resizedImageWithName:@"main_badge"] forState:UIControlStateNormal];
        self.titleLabel.font=[UIFont systemFontOfSize:11];
    }
    return self;
}

-(void)setBadgeValue:(NSString *)badgeValue
{
    //copy不能直接赋值
    _badgeValue=badgeValue;
    
    //设置提醒数字
    if(badgeValue)
    {
        self.hidden=NO;
        //设置文字
        [self setTitle:badgeValue forState:UIControlStateNormal];
        //设置frame,只设置自己的尺寸，不设置位置
        CGRect frame=self.frame;
        CGFloat badgeH=self.currentBackgroundImage.size.height;
        CGFloat badgeW=self.currentBackgroundImage.size.width;
        if(badgeValue.length>1)
        {
            CGSize badgeSize=[self sizeWithText:badgeValue font:[UIFont systemFontOfSize:11] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
            badgeW=badgeSize.width+10;
        }
        frame.size.width=badgeW;
        frame.size.height=badgeH;
        self.frame=frame;
        
    }
    else
    {
        self.hidden=YES;
    }
}

@end
