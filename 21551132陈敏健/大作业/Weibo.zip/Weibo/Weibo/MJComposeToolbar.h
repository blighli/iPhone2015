//
//  MJComposeToolbar.h
//  Weibo
//
//  Created by 敏少eclipse on 15/9/3.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MJComposeToolbar;
typedef enum{
    MJComposeToolbarBtnTypeCamera,
    MJComposeToolbarBtnTypePicture,
    MJComposeToolbarBtnTypeMention,
    MJComposeToolbarBtnTypeTrend,
    MJComposeToolbarBtnTypeEmotion,
} MJComposeToolbarBtnType;

@protocol MJComposeToolbarDelegate <NSObject>

@optional
-(void)composeToolbar:(MJComposeToolbar *)toolbar didClickedButton:(MJComposeToolbarBtnType)buttonType;

@end

@interface MJComposeToolbar : UIView
@property (nonatomic,weak) id<MJComposeToolbarDelegate> delegate;
@end
