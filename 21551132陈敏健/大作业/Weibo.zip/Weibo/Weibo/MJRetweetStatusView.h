//
//  MJRetweetStatusView.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/31.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MJStatusFrame;
@interface MJRetweetStatusView : UIImageView
@property (nonatomic,strong) MJStatusFrame * statusFrame;
@end
