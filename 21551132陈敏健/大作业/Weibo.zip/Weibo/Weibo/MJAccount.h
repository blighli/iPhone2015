//
//  MJAccount.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/28.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MJAccount : NSObject<NSCoding>
@property (nonatomic,copy) NSString * access_token;
@property (nonatomic,assign) long long expires_in;
@property (nonatomic,assign) long long remind_in;
@property (nonatomic,assign) long long uid;
@property (nonatomic,copy) NSDate * expiresTime;//过期时间

//用户名
@property (nonatomic,copy) NSString * name;

+(instancetype)accountWithDict:(NSDictionary *)dict;
-(instancetype)initWithDict:(NSDictionary *)dict;
@end
