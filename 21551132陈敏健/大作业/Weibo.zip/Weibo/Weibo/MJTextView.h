//
//  MJTextView.h
//  Weibo
//
//  Created by 敏少eclipse on 15/9/2.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MJTextView : UITextView
@property (nonatomic,copy) NSString * placeholder;
@property (nonatomic,strong) UIColor * placeholderColor;

@end
