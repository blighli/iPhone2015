//
//  MJStatusFrame.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/29.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJStatusFrame.h"
#import "MJPhotosView.h"
#import "MJStatus.h"
@implementation MJStatusFrame

//计算文字尺寸
-(CGSize)sizeWithText:(NSString *)text font:(UIFont *)font maxSize:(CGSize)maxSize
{
    NSDictionary *attrs=@{NSFontAttributeName:font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}

//获得微博模型数据之后，根据数据计算所有frame
-(void)setStatus:(MJStatus *)status
{
    _status=status;
    
    //cell的宽度
    CGFloat cellW=[UIScreen mainScreen].bounds.size.width-2*MJStatusTableBorder;
    
    //topView
    CGFloat topViewW=cellW;
    CGFloat topViewX=0;
    CGFloat topViewY=0;
    CGFloat topViewH=0;
    
    
    //头像
    CGFloat iconViewWH=35;
    CGFloat iconViewX=MJStatusCellBorder;
    CGFloat iconViewY=MJStatusCellBorder;
    _iconViewF=CGRectMake(iconViewX, iconViewY, iconViewWH, iconViewWH);
    
    //昵称
    CGFloat nameLabelX=CGRectGetMaxX(_iconViewF)+MJStatusCellBorder;
    CGFloat nameLabelY=iconViewY;
    CGSize nameLabelSize=[self sizeWithText:status.user.name font:MJStatusNameFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    _nameLabelF=(CGRect){{nameLabelX,nameLabelY},nameLabelSize};
    
    //会员图标
    if(status.user.mbtype>2)
    {
        CGFloat vipViewW=14;
        CGFloat vipViewH=nameLabelSize.height;
        CGFloat vipViewX=CGRectGetMaxX(_nameLabelF)+MJStatusCellBorder;
        CGFloat vipViewY=nameLabelY;
        _vipViewF=CGRectMake(vipViewX, vipViewY, vipViewW, vipViewH);
    }
    
    //时间
    CGFloat timeLabelX=nameLabelX;
    CGFloat timeLabelY=CGRectGetMaxY(_nameLabelF)+MJStatusCellBorder;
    CGSize timeLabelSize=[self sizeWithText:status.created_at font:MJStatusTimeFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    _timeLabelF=(CGRect){{timeLabelX,timeLabelY},timeLabelSize};
    
    //来源
    CGFloat sourceLabelX=CGRectGetMaxX(_timeLabelF)+MJStatusCellBorder;
    CGFloat sourceLabelY=timeLabelY;
    CGSize sourceLabelSize=[self sizeWithText:status.source font:MJStatusSourceFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    _sourceLabelF=(CGRect){{sourceLabelX,sourceLabelY},sourceLabelSize};
    
    //微博正文内容
    CGFloat contentLabelX=iconViewX;
    CGFloat contentLabelY=MAX(CGRectGetMaxY(_timeLabelF), CGRectGetMaxY(_iconViewF)+MJStatusCellBorder);
    CGFloat contentLabelMaxW=topViewW-2*MJStatusCellBorder;
    CGSize contentLabelSize=[self sizeWithText:status.text font:MJStatusContentFont maxSize:CGSizeMake(contentLabelMaxW, MAXFLOAT)];
    _contentLabelF=(CGRect){{contentLabelX,contentLabelY},contentLabelSize};
    
    //配图
    if(status.pic_urls.count)
    {
        CGSize photosViewSize=[MJPhotosView photosViewSizeWithPhotosCount:status.pic_urls.count];
        CGFloat photosViewX=contentLabelX;
        CGFloat photosViewY=CGRectGetMaxY(_contentLabelF)+MJStatusCellBorder;
        _photosViewF=CGRectMake(photosViewX, photosViewY, photosViewSize.width, photosViewSize.height);
    }
    
    //被转发微博
    if(status.retweeted_status)
    {
        CGFloat retweetedViewW=contentLabelMaxW;
        CGFloat retweetedViewX=contentLabelX;
        CGFloat retweetedViewY=CGRectGetMaxY(_contentLabelF)+MJStatusCellBorder;
        CGFloat retweetedViewH=0;
        
        //被转发微博的昵称
        CGFloat retweetedNameLabelX=MJStatusCellBorder;
        CGFloat retweetedNameLabelY=MJStatusCellBorder;
        CGSize retweetedNameLabelSize=[self sizeWithText:[NSString stringWithFormat:@"@%@",status.retweeted_status.user.name] font:MJRetweetedStatusNameFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
        _retweetedNameLabelF=(CGRect){{retweetedNameLabelX,retweetedNameLabelY},retweetedNameLabelSize};
        
        //被转发微博的正文
        CGFloat retweetedContentLabelX=retweetedNameLabelX;
        CGFloat retweetedContentLabelY=CGRectGetMaxY(_retweetedNameLabelF)+MJStatusCellBorder;
        CGFloat retweetedContentLabelMaxW=retweetedViewW-2*MJStatusCellBorder;
        CGSize retweetedContentLabelSize=[self sizeWithText:status.retweeted_status.text font:MJRetweetedStatusContentFont maxSize:CGSizeMake(retweetedContentLabelMaxW, MAXFLOAT)];
        _retweetedContentLabelF=(CGRect){{retweetedContentLabelX,retweetedContentLabelY},retweetedContentLabelSize};
        
        //被转发微博的配图
        if(status.retweeted_status.pic_urls.count){
            CGSize retweetedPhotoViewSize=[MJPhotosView photosViewSizeWithPhotosCount:status.retweeted_status.pic_urls.count];
            CGFloat retweetedPhotoViewX=retweetedContentLabelX;
            CGFloat retweetedPhotoViewY=CGRectGetMaxY(_retweetedContentLabelF)+MJStatusCellBorder;
            _retweetedPhotosViewF=CGRectMake(retweetedPhotoViewX, retweetedPhotoViewY, retweetedPhotoViewSize.width, retweetedPhotoViewSize.height);
            
            retweetedViewH=CGRectGetMaxY(_retweetedPhotosViewF);
        }
        else{
            retweetedViewH=CGRectGetMaxY(_retweetedContentLabelF);
        }
        retweetedViewH+=MJStatusCellBorder;
        _retweetedViewF=CGRectMake(retweetedViewX, retweetedViewY, retweetedViewW, retweetedViewH);
     
        //有转发微博时，topView的高度
        topViewH=CGRectGetMaxY(_retweetedViewF);
    }else{//没有转发微博
        if(status.pic_urls.count)//有图
        {
            topViewH=CGRectGetMaxY(_photosViewF);
        }
        else//无图
        {
            topViewH=CGRectGetMaxY(_contentLabelF);
        }
    }
    topViewH+=MJStatusCellBorder;
    _topViewF=CGRectMake(topViewX, topViewY, topViewW, topViewH);
    
    //工具条
    CGFloat statusToolbarX=topViewX;
    CGFloat statusToolbarY=CGRectGetMaxY(_topViewF);
    CGFloat statusToolbarW=topViewW;
    CGFloat statusToolbarH=35;
    _statusToolBarF=CGRectMake(statusToolbarX, statusToolbarY, statusToolbarW, statusToolbarH);
    
    //计算cell高度
    _cellHeight=CGRectGetMaxY(_statusToolBarF)+MJStatusTableBorder;
}

@end
