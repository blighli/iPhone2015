//
//  MJTabBarButton.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/25.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJTabBarButton.h"
#import "UIImage+MJ.h"
#import "MJBadgeButton.h"
#define MJTabBarButtonImageRatio 0.6
#define iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >=7.0)
#define MJTabBarButtonTitleColor (iOS7?[UIColor blackColor]:[UIColor whiteColor])
#define MJTabBarButtonTitleSelectedColor (iOS7?[UIColor orangeColor]:[UIColor orangeColor])

@interface MJTabBarButton()
@property (nonatomic,weak) MJBadgeButton * badgeButton;
@end
@implementation MJTabBarButton

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        self.imageView.contentMode=UIViewContentModeCenter;
        self.titleLabel.textAlignment=NSTextAlignmentCenter;
        self.titleLabel.font=[UIFont systemFontOfSize:12];
        [self setTitleColor:MJTabBarButtonTitleColor forState:UIControlStateNormal];
        [self setTitleColor:MJTabBarButtonTitleSelectedColor forState:UIControlStateSelected];
        if(!iOS7)
        {
            [self setBackgroundImage:[UIImage imageWithName:@"tabbar_slider"] forState:UIControlStateSelected];
        }
        
        //添加一个提醒数字按钮
        MJBadgeButton *badgeButton=[[MJBadgeButton alloc] init];
        //当将来父控件宽度变化时，badgeButton会发生改变,用在这个场合，不是固定的
        badgeButton.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin|UIViewAutoresizingFlexibleBottomMargin;
        [self addSubview:badgeButton];
        self.badgeButton=badgeButton;
    }
    return self;
}

-(void)setItem:(UITabBarItem *)item
{
    _item=item;
    
    //KVO,监听对象某个属性的改变
    [item addObserver:self forKeyPath:@"title" options:0 context:nil];
    [item addObserver:self forKeyPath:@"image" options:0 context:nil];
    [item addObserver:self forKeyPath:@"selectedImage" options:0 context:nil];
    [item addObserver:self forKeyPath:@"badgeValue" options:0 context:nil];
    
    //手动调用监听改动，使属性显示出来
    [self observeValueForKeyPath:nil ofObject:nil change:nil context:nil];
}

-(void)dealloc
{
    //监听需要释放
    [self.item removeObserver:self forKeyPath:@"title"];
    [self.item removeObserver:self forKeyPath:@"image"];
    [self.item removeObserver:self forKeyPath:@"selectedImage"];
    [self.item removeObserver:self forKeyPath:@"badgeValue"];

}

//监听某个对象的属性改变了，就会调用
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    //由于是选择状态改变，所以选择状态也需要设置
    [self setTitle:self.item.title forState:UIControlStateNormal];
    [self setTitle:self.item.title forState:UIControlStateSelected];
    
    [self setImage:self.item.image forState:UIControlStateNormal];
    [self setImage:self.item.selectedImage forState:UIControlStateSelected];
    
    //设置提醒数字,设置后BadgeButton就有W和H
    self.badgeButton.badgeValue=self.item.badgeValue;
    //设置提醒数字的位置
    CGFloat badgeY=5;
    CGFloat badgeX=self.frame.size.width-self.badgeButton.frame.size.width-10;
    CGRect badgeF=self.badgeButton.frame;
    badgeF.origin.x=badgeX;
    badgeF.origin.y=badgeY;
    self.badgeButton.frame=badgeF;
    
}

-(CGRect)imageRectForContentRect:(CGRect)contentRect
{
    CGFloat imageW=contentRect.size.width;
    CGFloat imageH=contentRect.size.height*MJTabBarButtonImageRatio;
    return CGRectMake(0, 0, imageW, imageH);
}

-(CGRect)titleRectForContentRect:(CGRect)contentRect
{
    CGFloat titleY=contentRect.size.height*MJTabBarButtonImageRatio;
    CGFloat titleW=contentRect.size.width;
    CGFloat titleH=contentRect.size.height*(1-MJTabBarButtonImageRatio);
    return CGRectMake(0, titleY, titleW, titleH);
}

-(void)setHighlighted:(BOOL)highlighted
{
    
}

@end
