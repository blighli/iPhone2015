//
//  MJRetweetStatusView.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/31.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJPhoto.h"
#import "MJRetweetStatusView.h"
#import "UIImage+MJ.h"
#import "MJStatusFrame.h"
#import "MJStatus.h"
#import "MJPhotosView.h"
#import "UIImageView+WebCache.h"

@interface MJRetweetStatusView()
//被转发微博作者的昵称
@property (nonatomic,weak) UILabel * retweetedNameLabel;
//被转发微博的内容
@property (nonatomic,weak) UILabel * retweetedContentLabel;
//被转发微博的配图
@property (nonatomic,weak) MJPhotosView * retweetedPhotosView;
@end
@implementation MJRetweetStatusView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        //设置可交互
        self.userInteractionEnabled=YES;
        //设置背景图片
        self.image=[UIImage resizedImageWithName:@"timeline_retweet_background" left:0.9 top:0.9];
        
        //被转发微博作者的昵称
        UILabel *retweetedNameLabel=[[UILabel alloc] init];
        retweetedNameLabel.font=MJRetweetedStatusNameFont;
        [self addSubview:retweetedNameLabel];
        self.retweetedNameLabel=retweetedNameLabel;
        
        //被转发微博的内容
        UILabel *retweetedContentLabel=[[UILabel alloc] init];
        retweetedContentLabel.font=MJRetweetedStatusContentFont;
        retweetedContentLabel.numberOfLines=0;
        [self addSubview:retweetedContentLabel];
        self.retweetedContentLabel=retweetedContentLabel;
        
        //被转发微博的配图
        MJPhotosView *retweetedPhotosView=[[MJPhotosView alloc] init];
        [self addSubview:retweetedPhotosView];
        self.retweetedPhotosView=retweetedPhotosView;
    }
    return self;
}

-(void)setStatusFrame:(MJStatusFrame *)statusFrame
{
    _statusFrame=statusFrame;
    
    MJStatus * retweetedStatus=statusFrame.status.retweeted_status;
    MJUser * user=retweetedStatus.user;
    
    self.retweetedNameLabel.text=[NSString stringWithFormat:@"@%@",user.name];
    self.retweetedNameLabel.frame=self.statusFrame.retweetedNameLabelF;
    
    self.retweetedContentLabel.text=retweetedStatus.text;
    self.retweetedContentLabel.frame=self.statusFrame.retweetedContentLabelF;
    
    if(retweetedStatus.pic_urls.count)
    {
        self.retweetedPhotosView.hidden=NO;
        self.retweetedPhotosView.frame=self.statusFrame.retweetedPhotosViewF;
        //传递数据
        self.retweetedPhotosView.photos=retweetedStatus.pic_urls;
    }
    else{
        self.retweetedPhotosView.hidden=YES;
    }

}

@end
