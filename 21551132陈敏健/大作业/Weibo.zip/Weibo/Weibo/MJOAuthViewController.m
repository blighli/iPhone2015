//
//  MJOAuthViewController.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/28.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJCommon.h"
#import "MJNewFeatureViewController.h"
#import "MJTabBarViewController.h"
#import "MJOAuthViewController.h"
#import "AFNetworking.h"
#import "MJAccount.h"
#import "MJAccountTools.h"
#import "MJWeiboTools.h"
#import "MBProgressHUD+MJ.h"
@interface MJOAuthViewController()<UIWebViewDelegate>

@end
@implementation MJOAuthViewController


-(void)viewDidLoad
{
    [super viewDidLoad];
    
    //添加webView
    UIWebView * webView=[[UIWebView alloc] init];
    webView.delegate=self;
    webView.frame=self.view.bounds;
    [self.view addSubview:webView];
    
    //加载授权页面
    NSURL *url=[NSURL URLWithString:@"https://api.weibo.com/oauth2/authorize?client_id=2448241402&redirect_uri=http://www.baidu.com"];
    NSURLRequest *request=[NSURLRequest requestWithURL:url];
    [webView loadRequest:request];
}

//webview代理方法,当webview发送一个请求之前会调用这个方法，询问代理可不可以加载这个请求
-(BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSString *urlStr=request.URL.absoluteString;
    NSRange range=[urlStr rangeOfString:@"code="];
    if(range.length!=0)
    {
        NSLog(@"%@",request.URL);
        //截取code=后面的请求标记（经过用户授权成功的）
        int loc=range.location+range.length;
        NSString *code=[urlStr substringFromIndex:loc];
        NSLog(@"%@",code);
        
        //发生post请求给新浪，通过code换取一个accessToken
        [self accessTokenWithCode:code];
        
        //不加载请求 
        return NO;
    }
    return YES;
}

//webView开始发生请求时候就会调用
-(void)webViewDidStartLoad:(UIWebView *)webView
{
    [MBProgressHUD showMessage:@"正在加载..."];
}
//webView请求完毕时候会调用
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [MBProgressHUD hideHUD];
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [MBProgressHUD hideHUD];
}

-(void)accessTokenWithCode:(NSString *)code
{
    //使用框架AFNetworking
    //创建请求管理类
    AFHTTPRequestOperationManager *mgr=[AFHTTPRequestOperationManager manager];
    
    //说明服务器返回的是JSON数据
    mgr.responseSerializer=[AFJSONResponseSerializer serializer];
    
    
    //封装请求参数
    NSMutableDictionary *params=[NSMutableDictionary dictionary];
    params[@"client_id"]=MJAppKey;
    params[@"client_secret"]=MJAppSecret;
    params[@"grant_type"]=@"authorization_code";
    params[@"code"]=code;
    params[@"redirect_uri"]=MJRedirectURI;
    
    //发生请求
    [mgr POST:@"https://api.weibo.com/oauth2/access_token" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"%@",[responseObject class]);
        NSLog(@"%@",responseObject);
        
        //字典转为模型
        MJAccount *account=[MJAccount accountWithDict:responseObject];
        
        //存储模型
        [MJAccountTools saveAccount:account];
        
         //跳转到新特性或首页
        [MJWeiboTools chooseRootViewController];

        //隐藏提醒框
        [MBProgressHUD hideHUD];
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        [MBProgressHUD hideHUD];
    }];
}

@end
