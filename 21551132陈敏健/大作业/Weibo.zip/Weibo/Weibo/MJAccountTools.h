//
//  MJAccountTools.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/28.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MJAccount.h"
@interface MJAccountTools : NSObject
+(void)saveAccount:(MJAccount *)account;
+(MJAccount *)account;
@end
