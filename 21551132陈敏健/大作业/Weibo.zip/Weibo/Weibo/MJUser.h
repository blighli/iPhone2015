//
//  MJUser.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/29.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MJUser : NSObject
//用户ID
@property (nonatomic,copy) NSString * idstr;
//用户昵称
@property (nonatomic,copy) NSString * name;
//用户头像
@property (nonatomic,copy) NSString * profile_image_url;
//会员等级
@property (nonatomic,assign) int mbrank;
//>2为会员
@property (nonatomic,assign) int mbtype;
@end
