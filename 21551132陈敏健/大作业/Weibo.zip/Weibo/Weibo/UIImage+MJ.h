//
//  UIImage+MJ.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/25.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (MJ)
//通过这个方法使图片自动适配版本
+(UIImage *)imageWithName:(NSString *)name;
+(UIImage *)resizedImageWithName:(NSString *)name;
+(UIImage *)resizedImageWithName:(NSString *)name left:(CGFloat)left top:(CGFloat)top;
@end
