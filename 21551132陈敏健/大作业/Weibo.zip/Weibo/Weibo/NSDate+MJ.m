//
//  NSDate+MJ.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/30.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "NSDate+MJ.h"

@implementation NSDate (MJ)
-(BOOL)isToday
{
    NSCalendar *calendar=[NSCalendar currentCalendar];
    
    int unit=NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay;
    
    NSDateComponents *selfCmps=[calendar components:unit fromDate:self];
    
    NSDateComponents *nowCmps=[calendar components:unit fromDate:[NSDate date]];
    
    return (selfCmps.year==nowCmps.year)&&(selfCmps.month==nowCmps.month)&&(selfCmps.day==nowCmps.day);
}

-(BOOL)isYesterday
{
    NSData *nowDate=[[NSDate date] dateWithYMD];
    
    NSDate *selfDate=[self dateWithYMD];
    
    NSCalendar *calendar=[NSCalendar currentCalendar];
    NSDateComponents *cmps=[calendar components:NSCalendarUnitDay fromDate:selfDate toDate:nowDate options:0];
    return cmps.day==1;
    
}

-(BOOL)isThisYear
{
    NSCalendar *calendar=[NSCalendar currentCalendar];
    
    int unit=NSCalendarUnitYear|NSCalendarUnitMonth|NSCalendarUnitDay;
    
    NSDateComponents *selfCmps=[calendar components:unit fromDate:self];
    
    NSDateComponents *nowCmps=[calendar components:unit fromDate:[NSDate date]];
    
    return selfCmps.year==nowCmps.year;
}

-(NSDateComponents *)deltaWithNow
{
    NSCalendar *calendar=[NSCalendar currentCalendar];
    int unit=NSCalendarUnitHour|NSCalendarUnitMinute|NSCalendarUnitSecond;
    return [calendar components:unit fromDate:self toDate:[NSDate date] options:0];
}

-(NSDate *)dateWithYMD
{
    NSDateFormatter *fmt=[[NSDateFormatter alloc] init];
    fmt.dateFormat=@"yyyy-MM-dd";
    NSString *str=[fmt stringFromDate:self];
    return [fmt dateFromString:str];
    
}

@end
