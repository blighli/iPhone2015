//
//  MJWeiboTools.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/28.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJWeiboTools.h"
#import "MJTabBarViewController.h"
#import "MJNewFeatureViewController.h"
@implementation MJWeiboTools
+(void)chooseRootViewController
{
    //跳转到新特性或首页
    NSString *key=@"CFBundleVersion";
    //取得沙盒中存储的上次使用软件的版本号
    NSUserDefaults *defaults=[NSUserDefaults standardUserDefaults];
    NSString *lastVersion=[defaults stringForKey:key];
    //获得当前软件的版本号
    NSString *currentVersion=[NSBundle mainBundle].infoDictionary[key];
    //比较版本号，不同则显示新特性
    if([currentVersion isEqualToString:lastVersion])
    {
        [UIApplication sharedApplication].keyWindow.rootViewController=[[MJTabBarViewController alloc] init];
    }
    else
    {
        [UIApplication sharedApplication].keyWindow.rootViewController=[[MJNewFeatureViewController alloc] init];
        [defaults setObject:currentVersion forKey:key];
        [defaults synchronize];
    }
}
@end
