//
//  MJTitleButton.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/27.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJTitleButton.h"
#import "UIImage+MJ.h"
#define MJImageWidth 30
@implementation MJTitleButton
+(instancetype)titleButton
{
    return [[self alloc] init];
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
            self.adjustsImageWhenHighlighted=NO;
        self.imageView.contentMode=UIViewContentModeCenter;
        self.titleLabel.font=[UIFont boldSystemFontOfSize:19];
        self.titleLabel.contentMode=UITextAlignmentCenter;
            [self setBackgroundImage:[UIImage imageWithName:@"navigationbar_filter_background_highlighted"] forState:UIControlStateHighlighted];
            [self setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    }
    return self;
}

-(CGRect)imageRectForContentRect:(CGRect)contentRect
{
        CGFloat imageY=0;
        CGFloat imageW=MJImageWidth;
        CGFloat imageH=contentRect.size.height;
        CGFloat imageX=contentRect.size.width-imageW;
    return CGRectMake(imageX, imageY, imageW, imageH);
}

-(CGRect)titleRectForContentRect:(CGRect)contentRect
{
    CGFloat titleY=0;
    CGFloat titleW=contentRect.size.width-30;
    CGFloat titleH=contentRect.size.height;
    CGFloat titleX=0;
    return CGRectMake(titleX, titleY, titleW, titleH);
}

//重写方法,使按钮根据文字设置大小
-(void)setTitle:(NSString *)title forState:(UIControlState)state
{
    CGFloat titleW=[self sizeWithText:title font:[UIFont systemFontOfSize:19] maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)].width;
    CGRect frame=self.frame;
    frame.size.width=titleW+MJImageWidth+5;
    self.frame=frame;
    
    [super setTitle:title forState:state];
}

//计算文字尺寸
-(CGSize)sizeWithText:(NSString *)text font:(UIFont *)font maxSize:(CGSize)maxSize
{
    NSDictionary *attrs=@{NSFontAttributeName:font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}

@end
