//
//  MJTabBar.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/25.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJTabBar.h"
#import "UIImage+MJ.h"
#import "MJTabBarButton.h"
#define iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >=7.0)
@interface MJTabBar()
@property (nonatomic,weak) UIButton * plusBtn;
@property (nonatomic,strong) NSMutableArray * tabBarButtons;
@property (nonatomic,strong) UIButton * selectedButton;
@end
@implementation MJTabBar

-(NSMutableArray *)tabBarButtons
{
    if(_tabBarButtons==nil)
    {
        _tabBarButtons=[NSMutableArray array];
    }
    return _tabBarButtons;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        if(!iOS7){
            self.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageWithName:@"tabbar_background"]];
        }
        
        //加号按钮
        UIButton *plusBtn=[UIButton buttonWithType:UIButtonTypeCustom];
        [plusBtn setBackgroundImage:[UIImage imageWithName:@"tabbar_compose_button"] forState:UIControlStateNormal];
        [plusBtn setBackgroundImage:[UIImage imageWithName:@"tabbar_compose_button_highlighted"] forState:UIControlStateHighlighted];
        [plusBtn setImage:[UIImage imageWithName:@"tabbar_compose_icon_add"] forState:UIControlStateNormal];
        [plusBtn setImage:[UIImage imageWithName:@"tabbar_compose_icon_add_highlighted"] forState:UIControlStateHighlighted];
        //这里乘以2，是因为没有合适的图片，因为Retina屏幕，一个点有两个像素
        plusBtn.bounds=CGRectMake(0, 0, plusBtn.currentImage.size.width*2, plusBtn.currentImage.size.height*2);
        [plusBtn addTarget:self action:@selector(plusBtnClick) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:plusBtn];
        self.plusBtn=plusBtn;
    }
    return self;
}

-(void)plusBtnClick
{
    if([self.delegate respondsToSelector:@selector(tabBarDidClickedPlusBtn:)])
    {
        [self.delegate tabBarDidClickedPlusBtn:self];
    }
}


-(void)addTabBarButton:(UITabBarItem *)item
{
    //创建按钮
    MJTabBarButton *button=[[MJTabBarButton alloc] init];
    [self addSubview:button];
    //设置数据
    button.item=item;
    
    //监听按钮点击
    [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchDown];
    
    //添加按钮到数组中
    [self.tabBarButtons addObject:button];
    
    //默认选中第0个按钮
    if(self.tabBarButtons.count==1)
    {
        [self buttonClick:button];
    }
}

-(void)buttonClick:(MJTabBarButton *)button
{
    //通知代理进行跳转
    if([self.delegate respondsToSelector:@selector(tabBar:didSelectedButtonFrom:to:)])
    {
        [self.delegate tabBar:self didSelectedButtonFrom:self.selectedButton.tag to:button.tag];
    }
    //设置按钮状态
    self.selectedButton.selected=NO;
    button.selected=YES;
    self.selectedButton=button;
    
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    NSLog(@"%lf---%lf",self.frame.size.width,self.frame.size.height);
    //跳转加号按钮的位置
    CGFloat h=self.frame.size.height;
    CGFloat w=self.frame.size.width;
    self.plusBtn.center=CGPointMake(w*0.5, h*0.5);
    
    //4个按钮，但宽度分成5份
    for(int i=0;i<self.tabBarButtons.count;i++)
    {
        MJTabBarButton *button=self.tabBarButtons[i];
        
        CGFloat buttonY=0;
        CGFloat buttonW=self.frame.size.width/self.subviews.count;
        CGFloat buttonH=self.frame.size.height;
        CGFloat buttonX=i*buttonW;
        if(i>1)
            buttonX+=buttonW;
        button.frame=CGRectMake(buttonX, buttonY, buttonW, buttonH);
        NSLog(@"lol");
        //绑定tag
        button.tag=i;
    }
}
@end
