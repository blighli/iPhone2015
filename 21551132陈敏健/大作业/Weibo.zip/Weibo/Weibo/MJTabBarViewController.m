//
//  MJTabBarViewController.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/25.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJComposeViewController.h"
#import "MJNavigationController.h"
#import "MJTabBarViewController.h"
#import "MJMeViewController.h"
#import "MJMessageViewController.h"
#import "MJHomeViewController.h"
#import "MJDiscoverViewController.h"
#import "UIImage+MJ.h"
#import "MJTabBar.h"
#define iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >=7.0)
@interface MJTabBarViewController ()<MJTabBarDelegate>
@property (nonatomic,weak) MJTabBar * customTabBar;
@end

@implementation MJTabBarViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupTabBar];
    
    [self setupAllChildViewControllers];
    
    //此时，刚加载完毕，UITabBar里没有自动加入进去的UITabBarButton
    
}

//view即将显示
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
    for(UIView *child in self.tabBar.subviews)
    {
        //不用UITabBarButton原因：是苹果的私有类，无法使用
        //用UIControl原因：UITabBarButton继承UIControl，MJTabBar不是
        if([child isKindOfClass:[UIControl class]])
        {
            [child removeFromSuperview];
        }
    }
}

-(void)setupTabBar
{
    MJTabBar *customTabBar=[[MJTabBar alloc] init];
    //customTabBar.backgroundColor=[UIColor redColor];
    customTabBar.frame=self.tabBar.bounds;
    [self.tabBar addSubview:customTabBar];
    self.customTabBar=customTabBar;
    self.customTabBar.delegate=self;
}

-(void)setupAllChildViewControllers
{
    MJHomeViewController * home=[[MJHomeViewController alloc] init];
    home.tabBarItem.badgeValue=@"1";
    [self setupChildViewController:home title:@"首页" imageName:@"tabbar_home" selectedImageName:@"tabbar_home_selected"];
    
    MJMessageViewController * message=[[MJMessageViewController alloc] init];
     message.tabBarItem.badgeValue=@"19";
    message.view.backgroundColor=[UIColor blueColor];
    [self setupChildViewController:message title:@"消息" imageName:@"tabbar_message_center" selectedImageName:@"tabbar_message_center_selected"];
    
    MJDiscoverViewController * discover=[[MJDiscoverViewController alloc] init];
    discover.view.backgroundColor=[UIColor orangeColor];
    discover.tabBarItem.badgeValue=@"new";
    [self setupChildViewController:discover title:@"广场" imageName:@"tabbar_discover" selectedImageName:@"tabbar_discover_selected"];
    
    MJMeViewController * me=[[MJMeViewController alloc] init];
    me.view.backgroundColor=[UIColor redColor];
    [self setupChildViewController:me title:@"我" imageName:@"tabbar_profile" selectedImageName:@"tabbar_profile_selected"];
}

-(void)setupChildViewController:(UIViewController *)viewController title:(NSString *)title imageName:(NSString *)imageName selectedImageName:(NSString *)selectedImageName
{
    viewController.tabBarItem.image=[UIImage imageWithName:imageName];
    //通过设置这个属性可以避免对图片进行过滤修改
    UIImage * selectedImage=[UIImage imageWithName:selectedImageName];
    //因为ios6不会自动过滤图片进行处理
    if(iOS7)
    viewController.tabBarItem.selectedImage=[selectedImage imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    else
        viewController.tabBarItem.selectedImage=selectedImage;
    //通过self.title可以同时为nav和tabbar设置title，好像已经失效了
    //self.title=title;
    viewController.tabBarItem.title=title;
    viewController.navigationItem.title=title;
    
    MJNavigationController *nav=[[MJNavigationController alloc] initWithRootViewController:viewController];
    [self addChildViewController:nav];
    
    [self.customTabBar addTabBarButton:viewController.tabBarItem];
}

-(void)tabBar:(MJTabBar *)tabBar didSelectedButtonFrom:(int)from to:(int)to
{
    self.selectedIndex=to;
}

-(void)tabBarDidClickedPlusBtn:(MJTabBar *)tabBar
{
    MJComposeViewController *compose=[[MJComposeViewController alloc] init];
    MJNavigationController *nav=[[MJNavigationController alloc] initWithRootViewController:compose];
    [self presentViewController:nav animated:YES completion:nil];
}

@end
