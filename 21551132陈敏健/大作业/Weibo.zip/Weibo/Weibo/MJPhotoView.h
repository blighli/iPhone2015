//
//  MJPhotoView.h
//  Weibo
//
//  Created by 敏少eclipse on 15/9/1.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>
@class  MJPhoto;
@interface MJPhotoView : UIImageView
@property (nonatomic,strong) MJPhoto * photo;
@end
