//
//  UIBarButtonItem+MJ.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/27.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "UIBarButtonItem+MJ.h"
#import "UIImage+MJ.h"
@implementation UIBarButtonItem (MJ)
+(UIBarButtonItem *)itemWithIcon:(NSString *)icon highIcon:(NSString *)highIcon target:(id)target action:(SEL)action
{
    UIButton *btn=[UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageWithName:icon] forState:UIControlStateNormal];
    [btn setBackgroundImage:[UIImage imageWithName:highIcon] forState:UIControlStateHighlighted];
    btn.bounds=CGRectMake(0, 0, btn.currentBackgroundImage.size.width, btn.currentBackgroundImage.size.height);
    [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return [[UIBarButtonItem alloc] initWithCustomView:btn];
}
@end
