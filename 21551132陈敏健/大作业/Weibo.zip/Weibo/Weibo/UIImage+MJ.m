//
//  UIImage+MJ.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/25.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "UIImage+MJ.h"
#define iOS7 ([[UIDevice currentDevice].systemVersion doubleValue] >=7.0)
@implementation UIImage (MJ)
+(UIImage *)imageWithName:(NSString *)name
{
    if (iOS7) {
        NSString * newName=[name stringByAppendingString:@"_os7"];
        UIImage *image=[UIImage imageNamed:newName];
        if(image==nil)
        {
            image=[UIImage imageNamed:name];
        }
        return image;
    }
    return [UIImage imageNamed:name];
}

+(UIImage *)resizedImageWithName:(NSString *)name
{
    return [self resizedImageWithName:name left:0.5 top:0.5];
}

+(UIImage *)resizedImageWithName:(NSString *)name left:(CGFloat)left top:(CGFloat)top
{
    UIImage *image=[self imageWithName:name];
    return [image stretchableImageWithLeftCapWidth:image.size.width*left topCapHeight:image.size.height*top];
}
@end
