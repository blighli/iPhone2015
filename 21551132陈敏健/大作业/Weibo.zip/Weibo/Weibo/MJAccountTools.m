//
//  MJAccountTools.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/28.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJAccountTools.h"
#import "MJAccount.h"
@implementation MJAccountTools
//存储登录账号
+(void)saveAccount:(MJAccount *)account
{
    //计算账号过期时间
    NSDate *now=[NSDate date];
    account.expiresTime=[now dateByAddingTimeInterval:account.expires_in];
    
    NSString *doc=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString * file=[doc stringByAppendingPathComponent:@"account.data"];
    [NSKeyedArchiver archiveRootObject:account toFile:file];
}
//取出登录账号
+(MJAccount *)account
{
    NSString *doc=[NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    NSString * file=[doc stringByAppendingPathComponent:@"account.data"];
    MJAccount *account= [NSKeyedUnarchiver unarchiveObjectWithFile:file];
    
    NSDate *now=[NSDate date];
    if([now compare:account.expiresTime]==NSOrderedAscending)
        return account;
    else
        return nil;
}
@end
