//
//  MJPhoto.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/31.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MJPhoto : NSObject
//缩略图
@property (nonatomic,copy) NSString * thumbnail_pic;
@end
