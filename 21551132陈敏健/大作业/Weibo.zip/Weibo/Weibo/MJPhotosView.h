//
//  MJPhotosView.h
//  Weibo
//
//  Created by 敏少eclipse on 15/9/1.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MJPhotosView : UIView

//数组里的是MJPhoto模型
@property (nonatomic,strong) NSArray * photos;
//根据图片的个数返回相册的最终尺寸
+(CGSize)photosViewSizeWithPhotosCount:(int)count;

@end
