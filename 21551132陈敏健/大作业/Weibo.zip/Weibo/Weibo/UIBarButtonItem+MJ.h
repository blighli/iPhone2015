//
//  UIBarButtonItem+MJ.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/27.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (MJ)
//导航栏上的按钮，有设置点击事件
+(UIBarButtonItem *)itemWithIcon:(NSString *)icon highIcon:(NSString *)highIcon target:(id)target action:(SEL)action;
@end
