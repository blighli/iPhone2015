//
//  MJStatusToolbar.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/31.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJStatusToolbar.h"
#import "UIImage+MJ.h"
#import "MJStatus.h"

@interface MJStatusToolbar()
@property (nonatomic,strong) NSMutableArray * btns;
@property (nonatomic,strong) NSMutableArray * dividers;
@property (nonatomic,weak) UIButton * retweetBtn;
@property (nonatomic,weak) UIButton * commentBtn;
@property (nonatomic,weak) UIButton * attitudeBtn;
@end
@implementation MJStatusToolbar

-(NSMutableArray *)btns
{
    if(_btns==nil)
    {
        _btns=[NSMutableArray array];
    }
    return _btns;
}

-(NSMutableArray *)dividers
{
    if(_dividers==nil)
    {
        _dividers=[NSMutableArray array];
    }
    return _dividers;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        //设置可交互
        self.userInteractionEnabled=YES;
        //设置图片
        self.image=[UIImage resizedImageWithName:@"timeline_card_bottom_background"];
        self.highlightedImage=[UIImage resizedImageWithName:@"timeline_card_bottom_background_highlighted"];
        
        //添加按钮
        self.retweetBtn=[self setupBtnWithTitle:@"转发" image:@"timeline_icon_retweet" bgImage:@"timeline_card_leftbottom_highlighted"];
        self.commentBtn=[self setupBtnWithTitle:@"评论" image:@"timeline_icon_comment" bgImage:@"timeline_card_middlebottom_highlighted"];
        self.attitudeBtn=[self setupBtnWithTitle:@"赞" image:@"timeline_icon_unlike" bgImage:@"timeline_card_rightbottom_highlighted"];
        //添加分割线
        [self setupDivider];
        [self setupDivider];
    }
    return self;
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    
    //设置按钮
    CGFloat btnW=self.frame.size.width/self.btns.count;
    CGFloat btnH=self.frame.size.height;
    for(int i=0;i<self.btns.count;i++)
    {
        UIButton *btn=self.btns[i];
        
        CGFloat btnX=btnW*i;
        CGFloat btnY=0;
        btn.frame=CGRectMake(btnX, btnY, btnW, btnH);
    }
    //设置分割线
    CGFloat dividerH=btnH;
    CGFloat dividerW=2;
    CGFloat dividerY=0;
    for (int i=0; i<self.dividers.count; i++) {
        UIImageView *divider=self.dividers[i];
        CGFloat dividerX=(i+1)*btnW;
        divider.frame=CGRectMake(dividerX, dividerY, dividerW, dividerH);
    }
}

//初始化按钮，并且返回按钮
-(UIButton *)setupBtnWithTitle:(NSString *)title image:(NSString *)image bgImage:(NSString *)bgImage
{
    UIButton *btn=[[UIButton alloc] init];
    [btn setImage:[UIImage imageWithName:image] forState:UIControlStateNormal];
    [btn setTitle:title forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    btn.titleLabel.font=[UIFont systemFontOfSize:13];
    btn.titleEdgeInsets=UIEdgeInsetsMake(0, 5, 0, 0);
    [btn setBackgroundImage:[UIImage imageWithName:bgImage] forState:UIControlStateHighlighted];
    btn.adjustsImageWhenHighlighted=NO;
    [self addSubview:btn];
    
    [self.btns addObject:btn];
    
    return btn;
}

-(void)setupDivider
{
    UIImageView *divider=[[UIImageView alloc] init];
    divider.image=[UIImage imageWithName:@"timeline_card_bottom_line"];
    [self addSubview:divider];
    
    [self.dividers addObject:divider];
}

-(void)setStatus:(MJStatus *)status
{
    _status=status;
    
    //设置按钮
    [self setupBtn:self.retweetBtn originalTitle:@"转发" count:status.reposts_count];
    [self setupBtn:self.commentBtn originalTitle:@"评论" count:status.comments_count];
    [self setupBtn:self.attitudeBtn originalTitle:@"赞" count:status.attitudes_count];
    
}

-(void)setupBtn:(UIButton *)btn originalTitle:(NSString *)originalTitle count:(int)count
{
    if(count)
    {
        NSString *title=nil;
        if(count<10000)
        {
            title=[NSString stringWithFormat:@"%d",count];
        }else{
            double countDouble=count/10000.0;
            title=[NSString stringWithFormat:@"%.1f万",countDouble];
            title=[title stringByReplacingOccurrencesOfString:@".0" withString:@""];
        }
        [btn setTitle:title forState:UIControlStateNormal];
    }
    else{
        [btn setTitle:originalTitle forState:UIControlStateNormal];
    }
}

@end
