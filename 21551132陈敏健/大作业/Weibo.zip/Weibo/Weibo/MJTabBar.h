//
//  MJTabBar.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/25.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MJTabBar;
@protocol  MJTabBarDelegate<NSObject>

@optional
-(void)tabBar:(MJTabBar *)tabBar didSelectedButtonFrom:(int)from to:(int)to;
-(void)tabBarDidClickedPlusBtn:(MJTabBar *)tabBar;
@end

@interface MJTabBar : UIView
@property (nonatomic,weak) id<MJTabBarDelegate>  delegate;
-(void)addTabBarButton:(UITabBarItem *)item;
@end
