//
//  MJTextView.m
//  Weibo
//
//  Created by 敏少eclipse on 15/9/2.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJTextView.h"

@interface MJTextView()
@property (nonatomic,weak) UILabel * placeholderLabel;
@end
@implementation MJTextView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        //添加提示文字
        UILabel * placeholderLabel=[[UILabel alloc] init];
        placeholderLabel.textColor=[UIColor lightGrayColor];
        placeholderLabel.hidden=YES;
        placeholderLabel.numberOfLines=0;
        placeholderLabel.backgroundColor=[UIColor clearColor];
        placeholderLabel.font=self.font;
        [self addSubview:placeholderLabel];
        self.placeholderLabel=placeholderLabel;
        
        //监听文字改变的通知
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:self];
    }
    return self;
}

-(void)textDidChange
{
    self.placeholderLabel.hidden=(self.text.length!=0);
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)setPlaceholder:(NSString *)placeholder
{
    _placeholder=placeholder;
    
    self.placeholderLabel.text=placeholder;
    if (placeholder.length) {
        self.placeholderLabel.hidden=NO;
        
        CGFloat placeholderX=5;
        CGFloat placeholderY=7;
        CGFloat maxW=self.frame.size.width-2*placeholderX;
        CGFloat maxH=self.frame.size.height-2*placeholderY;
        CGSize placeholderSize=[self sizeWithText:self.placeholderLabel.text font:self.placeholderLabel.font maxSize:CGSizeMake(maxW, maxH)];
        self.placeholderLabel.frame=CGRectMake(placeholderX, placeholderY, placeholderSize.width, placeholderSize.height);
    }else{
        self.placeholderLabel.hidden=YES;
    }
}

-(void)setPlaceholderColor:(UIColor *)placeholderColor
{
    _placeholderColor=placeholderColor;
    
    self.placeholderLabel.textColor=placeholderColor;
}

-(void)setFont:(UIFont *)font
{
    [super setFont:font];
    
    self.placeholderLabel.font=font;
    self.placeholder=self.placeholder;
}

//计算文字尺寸
-(CGSize)sizeWithText:(NSString *)text font:(UIFont *)font maxSize:(CGSize)maxSize
{
    NSDictionary *attrs=@{NSFontAttributeName:font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}

@end
