//
//  MJComposePhotosView.m
//  Weibo
//
//  Created by 敏少eclipse on 15/9/3.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJComposePhotosView.h"

@implementation MJComposePhotosView

-(NSArray *)totalImages
{
    NSMutableArray *images=[NSMutableArray array];
    
    for (UIImageView * imageView in self.subviews) {
        [images addObject:imageView.image];
    }
    return images;
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)addImage:(UIImage *)image
{
    UIImageView *imageView=[[UIImageView alloc] init];
    imageView.image=image;
    [self addSubview:imageView];
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat imageViewW=70;
    CGFloat imageViewH=imageViewW;
    int maxColumn=4;//一行最多显示4张图片
    CGFloat margin=(self.frame.size.width-maxColumn*imageViewW)/(maxColumn+1);
    for (int i=0; i<self.subviews.count; i++) {
        UIImageView *imageView=self.subviews[i];
        
        CGFloat imageViewX=margin+(i%maxColumn)*(imageViewW+margin);
        CGFloat imageViewY=(i/maxColumn)*(imageViewH+margin);
        imageView.frame=CGRectMake(imageViewX, imageViewY, imageViewW, imageViewH);
    }
}

@end
