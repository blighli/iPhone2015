//
//  MJNewFeatureViewController.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/28.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJTabBarViewController.h"
#import "MJNewFeatureViewController.h"
#import "UIImage+MJ.h"
#define MJNewFeatureImageCount 3
@interface MJNewFeatureViewController()<UIScrollViewDelegate>
@property (nonatomic,weak) UIPageControl * pageControl;
@end
@implementation MJNewFeatureViewController

-(void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setupScrollView];
    [self setupPageControl];
}

//添加scrollView
-(void)setupScrollView
{
    //创建scrollView
    UIScrollView *scrollView=[[UIScrollView alloc] init];
    scrollView.frame=self.view.bounds;
    [self.view addSubview:scrollView];
    scrollView.delegate=self;
    
    //添加图片
    CGFloat imageW=scrollView.frame.size.width;
    CGFloat imageH=scrollView.frame.size.height;
    for(int i=0;i<MJNewFeatureImageCount;i++)
    {
        UIImageView *imageView=[[UIImageView alloc] init];
        NSString *name=[NSString stringWithFormat:@"new_feature_%d",i+1];
        imageView.image=[UIImage imageWithName:name];
        
        CGFloat imageX=i*imageW;
        CGFloat imageY=0;
        imageView.frame=CGRectMake(imageX, imageY, imageW, imageH);
        
        [scrollView addSubview:imageView];
        
        //在最后一个图片上面添加按钮
        if(i==MJNewFeatureImageCount-1)
        {
            [self setupLastImageView:imageView];
        }
    }
    
    //设置滚动的内容尺寸
    scrollView.contentSize=CGSizeMake(imageW*MJNewFeatureImageCount, 0);
    scrollView.showsHorizontalScrollIndicator=NO;
    scrollView.pagingEnabled=YES;
    //为了让拖到两边时好看点
    //设置无弹簧效果
    scrollView.bounces=NO;
}

-(void)setupPageControl
{
    UIPageControl * pageControl=[[UIPageControl alloc] init];
    pageControl.numberOfPages=MJNewFeatureImageCount;
    
    CGFloat centerX=self.view.frame.size.width*0.5;
    CGFloat centerY=self.view.frame.size.height-30;
    pageControl.center=CGPointMake(centerX, centerY);
    pageControl.bounds=CGRectMake(0, 0, 100, 30);
    [self.view addSubview:pageControl];
    self.pageControl=pageControl;
    
    pageControl.userInteractionEnabled=NO;
    
    pageControl.currentPageIndicatorTintColor=[UIColor colorWithPatternImage:[UIImage imageWithName:@"new_feature_pagecontrol_checked_point"]];
    pageControl.pageIndicatorTintColor=[UIColor colorWithPatternImage:[UIImage imageWithName:@"new_feature_pagecontrol_point"]];
    //无用
//    pageControl.currentPageIndicatorTintColor=[UIColor colorWithRed:253 green:98 blue:42 alpha:1];
//    pageControl.pageIndicatorTintColor=[UIColor colorWithRed:189 green:189 blue:189 alpha:1];
}

-(void)setupLastImageView:(UIImageView *)imageView
{
    //添加开始按钮
    //不然imageview不可与用户交互
    imageView.userInteractionEnabled=YES;
    
    UIButton *startBtn=[[UIButton alloc] init];
    [startBtn setBackgroundImage:[UIImage imageWithName:@"new_feature_finish_button"] forState:UIControlStateNormal];
    [startBtn setBackgroundImage:[UIImage imageWithName:@"new_feature_finish_button_highlighted"] forState:UIControlStateHighlighted];
    
    CGFloat centerX=self.view.frame.size.width*0.5;
    CGFloat centerY=self.view.frame.size.height*0.6;
    startBtn.center=CGPointMake(centerX, centerY);
    startBtn.bounds=(CGRect){CGPointZero,startBtn.currentBackgroundImage.size};
    
    [startBtn setTitle:@"开始微博" forState:UIControlStateNormal];
    [startBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    [startBtn addTarget:self action:@selector(start) forControlEvents:UIControlEventTouchUpInside];
    
    [imageView addSubview:startBtn];
    
    //添加checkbox
    UIButton *checkbox=[[UIButton alloc] init];
    [checkbox setTitle:@"分享给大家" forState:UIControlStateNormal];
    [checkbox setImage:[UIImage imageWithName:@"new_feature_share_false"] forState:UIControlStateNormal];
    [checkbox setImage:[UIImage imageWithName:@"new_feature_share_true"] forState:UIControlStateSelected];
    checkbox.bounds=startBtn.bounds;
    CGFloat checkboxCenterX=centerX;
    CGFloat checkboxCenterY=imageView.frame.size.height*0.5;
    checkbox.center=CGPointMake(checkboxCenterX, checkboxCenterY);
    [checkbox setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    checkbox.titleLabel.font=[UIFont systemFontOfSize:15];
    [checkbox addTarget:self action:@selector(checkboxClick:) forControlEvents:UIControlEventTouchUpInside];
    [imageView addSubview:checkbox];
}

-(void)checkboxClick:(UIButton *)checkbox
{
    checkbox.selected=!checkbox.selected;
}

-(void)start
{
    //切换根控制器
    self.view.window.rootViewController=[[MJTabBarViewController alloc] init];
}

//只要滚动，就会调用
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat offsetX=scrollView.contentOffset.x;
    
    double pageDouble=offsetX/scrollView.frame.size.width;
    int pageInt=(int)(pageDouble+0.5);
    self.pageControl.currentPage=pageInt;
}
@end
