//
//  MJSearchBar.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/27.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import "MJSearchBar.h"
#import "UIImage+MJ.h"

@interface MJSearchBar()
@property (nonatomic,weak) UIImageView * iconView;
@end
@implementation MJSearchBar
+(instancetype)searchBar
{
    return [[self alloc] init];
}

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        //背景
        self.background=[UIImage resizedImageWithName:@"searchbar_textfield_background"];
        //尺寸，由外部决定
        //self.frame=CGRectMake(0, 0, 300, 30);
        //左边的图标
        UIImageView *iconView=[[UIImageView alloc] initWithImage:[UIImage imageWithName:@"searchbar_textfield_search_icon"]];
        iconView.contentMode=UIViewContentModeCenter;
        self.leftView=iconView;
        self.leftViewMode=UITextFieldViewModeAlways;
        //字体
        self.font=[UIFont systemFontOfSize:13];
        //右边的清除按钮
        self.clearButtonMode=UITextFieldViewModeAlways;
        //提示文字
        NSMutableDictionary *attrs=[NSMutableDictionary dictionary];
        attrs[NSForegroundColorAttributeName]=[UIColor grayColor];
        self.attributedPlaceholder=[[NSAttributedString alloc] initWithString:@"搜索" attributes:attrs];
        //设置右下角按钮样式
        self.returnKeyType=UIReturnKeySearch;
        self.enablesReturnKeyAutomatically=YES;
    }
    return self;
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    
    self.leftView.frame=CGRectMake(0, 0, 30,self.frame.size.height);
}

@end
