//
//  MJOAuthViewController.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/28.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MJOAuthViewController : UIViewController

@end
