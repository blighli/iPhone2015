//
//  MJStatusTopView.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/31.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJStatusFrame.h"
#import "UIImageView+WebCache.h"
#import "MJStatus.h"
#import "MJPhoto.h"
#import "MJPhotosView.h"
#import "MJStatusTopView.h"
#import "UIImage+MJ.h"
#import "MJRetweetStatusView.h"
@interface MJStatusTopView()

//头像
@property (nonatomic,weak) UIImageView * iconView;
//会员图标
@property (nonatomic,weak) UIImageView * vipView;
//配图
@property (nonatomic,weak) MJPhotosView * photosView;
//昵称
@property (nonatomic,weak) UILabel * nameLabel;
//时间
@property (nonatomic,weak) UILabel * timeLabel;
//来源
@property (nonatomic,weak) UILabel * sourceLabel;
//内容
@property (nonatomic,weak) UILabel * contentLabel;

//被转发微博的view
@property (nonatomic,weak) MJRetweetStatusView * retweetedView;

@end
@implementation MJStatusTopView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        //设置可交互
        self.userInteractionEnabled=YES;
        
        self.image=[UIImage resizedImageWithName:@"timeline_card_top_background"];
        self.highlightedImage=[UIImage resizedImageWithName:@"timeline_card_top_background_highlighted"];
    
        
        //头像
        UIImageView *iconView=[[UIImageView alloc] init];
        [self addSubview:iconView];
        self.iconView=iconView;
        
        //会员图标
        UIImageView *vipView=[[UIImageView alloc] init];
        vipView.contentMode=UIViewContentModeCenter;
        [self addSubview:vipView];
        self.vipView=vipView;
        
        //昵称
        UILabel *nameLabel=[[UILabel alloc] init];
        nameLabel.font=MJStatusNameFont;
        [self addSubview:nameLabel];
        self.nameLabel=nameLabel;
        //时间
        UILabel *timeLabel=[[UILabel alloc] init];
        timeLabel.font=MJStatusTimeFont;
        [self addSubview:timeLabel];
        self.timeLabel=timeLabel;
        //来源
        UILabel *sourceLabel=[[UILabel alloc] init];
        sourceLabel.font=MJStatusSourceFont;
        [self addSubview:sourceLabel];
        self.sourceLabel=sourceLabel;
        //内容
        UILabel *contentLabel=[[UILabel alloc] init];
        contentLabel.font=MJStatusContentFont;
        contentLabel.numberOfLines=0;
        [self addSubview:contentLabel];
        self.contentLabel=contentLabel;
        
        //配图
        MJPhotosView *photosView=[[MJPhotosView alloc] init];
        [self addSubview:photosView];
        self.photosView=photosView;
        
        //被转发微博的view
        MJRetweetStatusView *retweetedView=[[MJRetweetStatusView alloc] init];
        [self addSubview:retweetedView];
        self.retweetedView=retweetedView;

    }
    return self;
}

-(void)setStatusFrame:(MJStatusFrame *)statusFrame
{
    _statusFrame=statusFrame;
    
    MJStatus *status=statusFrame.status;
    MJUser *user=status.user;
    
    
    [self.iconView sd_setImageWithURL:[NSURL URLWithString:user.profile_image_url] placeholderImage:[UIImage imageWithName:@"avatar_default_small"]];
    self.iconView.frame=self.statusFrame.iconViewF;
    
    self.nameLabel.text=user.name;
    self.nameLabel.frame=self.statusFrame.nameLabelF;
    
    if(user.mbtype>2){
        self.vipView.hidden=NO;
        self.vipView.image=[UIImage imageWithName:[NSString stringWithFormat:@"common_icon_membership_level%d",user.mbrank]];
        self.vipView.frame=self.statusFrame.vipViewF;
    }else{
        self.vipView.hidden=YES;
    }
    
    //时间
    self.timeLabel.text=status.created_at;
    CGFloat timeLabelX=self.statusFrame.nameLabelF.origin.x;
    CGFloat timeLabelY=CGRectGetMaxY(self.statusFrame.nameLabelF)+MJStatusCellBorder*0.5;
    CGSize timeLabelSize=[self sizeWithText:status.created_at font:MJStatusTimeFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    self.timeLabel.frame=(CGRect){{timeLabelX,timeLabelY},timeLabelSize};
    
    //来源
    self.sourceLabel.text=status.source;
    CGFloat sourceLabelX=CGRectGetMaxX(self.timeLabel.frame)+MJStatusCellBorder;
    CGFloat sourceLabelY=timeLabelY;
    CGSize sourceLabelSize=[self sizeWithText:status.source font:MJStatusSourceFont maxSize:CGSizeMake(MAXFLOAT, MAXFLOAT)];
    self.sourceLabel.frame=(CGRect){{sourceLabelX,sourceLabelY},sourceLabelSize};
    
    
    self.contentLabel.text=status.text;
    self.contentLabel.frame=self.statusFrame.contentLabelF;
    
    if(status.pic_urls.count)
    {
        self.photosView.hidden=NO;
        self.photosView.frame=self.statusFrame.photosViewF;
        
        //传递数据
        self.photosView.photos=status.pic_urls;
    }else{
        self.photosView.hidden=YES;
    }
    
    //被转发微博的信息
    MJStatus * retweetedStatus=self.statusFrame.status.retweeted_status;
    if(retweetedStatus)
    {
        self.retweetedView.hidden=NO;
        self.retweetedView.frame=self.statusFrame.retweetedViewF;
        
        //传递模型
        self.retweetedView.statusFrame=self.statusFrame;
        
    }else{
        self.retweetedView.hidden=YES;
    }
}

//计算文字尺寸
-(CGSize)sizeWithText:(NSString *)text font:(UIFont *)font maxSize:(CGSize)maxSize
{
    NSDictionary *attrs=@{NSFontAttributeName:font};
    return [text boundingRectWithSize:maxSize options:NSStringDrawingUsesLineFragmentOrigin attributes:attrs context:nil].size;
}

@end
