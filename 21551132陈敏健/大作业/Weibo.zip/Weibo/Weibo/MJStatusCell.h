//
//  MJStatusCell.h
//  Weibo
//
//  Created by 敏少eclipse on 15/8/29.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MJStatusFrame.h"
@interface MJStatusCell : UITableViewCell
@property (nonatomic,strong) MJStatusFrame * statusFrame;
+(instancetype)cellWithTableView:(UITableView *)tableView;
@end
