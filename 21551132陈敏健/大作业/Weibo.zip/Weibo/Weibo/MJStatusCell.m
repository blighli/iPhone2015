//
//  MJStatusCell.m
//  Weibo
//
//  Created by 敏少eclipse on 15/8/29.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJStatusFrame.h"
#import "MJStatus.h"
#import "UIImage+MJ.h"
#import "MJStatusTopView.h"
#import "MJStatusCell.h"
#import "MJStatusToolbar.h"
#import "MJRetweetStatusView.h"
#import "UIImageView+WebCache.h"

@interface MJStatusCell()
//顶部的view
@property (nonatomic,weak) MJStatusTopView * topView;

//微博工具条
@property (nonatomic,weak) MJStatusToolbar * statusToolBar;

@end
@implementation MJStatusCell
//把有可能显示的子控件全部加进去

+(instancetype)cellWithTableView:(UITableView *)tableView
{
    static NSString * ID=@"status";
    MJStatusCell *cell=[tableView dequeueReusableCellWithIdentifier:ID];
    if(cell==nil){
        cell=[[MJStatusCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:ID];
    }
    return cell;
}

//拦截frame的设置
-(void)setFrame:(CGRect)frame
{
    frame.origin.x=MJStatusTableBorder;
    frame.size.width-=2*MJStatusTableBorder;
    frame.size.height-=MJStatusTableBorder;
    [super setFrame:frame];
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self=[super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if(self)
    {
        //添加原创微博内部的子控件
        [self setupTopView];
        //添加微博的工具条
        [self setupStatusTool];
        
    }
    return self;
}

//添加原创微博内部的子控件
-(void)setupTopView
{
    //设置cell背景颜色,不要颜色，消除后面多余的白色部分
    self.backgroundColor=[UIColor clearColor];
    
    //顶部的view
    MJStatusTopView *topView=[[MJStatusTopView alloc] init];
    [self.contentView addSubview:topView];
    self.topView=topView;
    
}

//添加微博的工具条
-(void)setupStatusTool
{
    //微博工具条
    MJStatusToolbar *statusToolBar=[[MJStatusToolbar alloc] init];
    [self.contentView addSubview:statusToolBar];
    self.statusToolBar=statusToolBar;
    
    
}

-(void)setStatusFrame:(MJStatusFrame *)statusFrame
{
    _statusFrame=statusFrame;
    
    //原创微博
    [self setupTopViewData];
    //微博工具条
    [self setupStatusToolbarData];
}
//原创微博
-(void)setupTopViewData
{
    
    self.topView.frame=self.statusFrame.topViewF;
    self.topView.statusFrame=self.statusFrame;
    
}

-(void)setupStatusToolbarData
{
    self.statusToolBar.status=self.statusFrame.status;
    self.statusToolBar.frame=self.statusFrame.statusToolBarF;
}


@end
