//
//  MJPhotoView.m
//  Weibo
//
//  Created by 敏少eclipse on 15/9/1.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "UIImageView+WebCache.h"
#import "MJPhotoView.h"
#import "MJPhoto.h"
#import "UIImage+MJ.h"
@interface MJPhotoView()
@property (nonatomic,weak) UIImageView * gifView;
@end
@implementation MJPhotoView

-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if (self) {
        //添加一个GIF小图标
        UIImage *image=[UIImage imageWithName:@"timeline_image_gif"];
        UIImageView *gifView=[[UIImageView alloc] initWithImage:image];
        [self addSubview:gifView];
        self.gifView=gifView;
    }
    return self;
}

-(void)layoutSubviews
{
    [super layoutSubviews];
    
    //位于右下角
    //范围为0~1,相当于这个点在这个控件中的比例，这个点就在position的位置上
    self.gifView.layer.anchorPoint=CGPointMake(1, 1);
    self.gifView.layer.position=CGPointMake(self.frame.size.width, self.frame.size.height);
}

-(void)setPhoto:(MJPhoto *)photo
{
    _photo=photo;
    
    //控制gifView的可见性
    if ([photo.thumbnail_pic hasSuffix:@"gif"]) {
        self.gifView.hidden=NO;
    }
    else
    {
        self.gifView.hidden=YES;
    }
    
    //下载图片
    [self sd_setImageWithURL:[NSURL URLWithString:photo.thumbnail_pic] placeholderImage:[UIImage imageWithName:@"timeline_image_placeholder"]];
}

@end
