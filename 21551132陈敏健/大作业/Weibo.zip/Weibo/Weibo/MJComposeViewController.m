//
//  MJComposeViewController.m
//  Weibo
//
//  Created by 敏少eclipse on 15/9/2.
//  Copyright (c) 2015年 敏少eclipse. All rights reserved.
//
#import "MJAccountTools.h"
#import "MJAccount.h"
#import "MJComposePhotosView.h"
#import "MJComposeViewController.h"
#import "MJTextView.h"
#import "AFNetworking.h"
#import "MJComposeToolbar.h"
#import "MBProgressHUD+MJ.h"
@interface MJComposeViewController ()<UITextViewDelegate,MJComposeToolbarDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate>
@property (nonatomic,weak) MJTextView * textView;
@property (nonatomic,weak) MJComposeToolbar * toolbar;
@property (nonatomic,weak) MJComposePhotosView * photosView;
@end

@implementation MJComposeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setupNavBar];
    
    [self setupTextView];
    
    [self setupToolbar];
    
    [self setupPhotosView];
}

-(void)setupPhotosView
{
    MJComposePhotosView *photosView=[[MJComposePhotosView alloc] init];
    photosView.backgroundColor=[UIColor redColor];
    CGFloat photosW=self.textView.frame.size.width;
    CGFloat photosY=80;
    //因为后面也用不到，无所谓
    CGFloat photosH=self.textView.frame.size.height;
    CGFloat photosX=0;
    photosView.frame=CGRectMake(photosX, photosY, photosW, photosH);
    
    [self.textView addSubview:photosView];
    self.photosView=photosView;
}

-(void)setupToolbar
{
    MJComposeToolbar *toolbar=[[MJComposeToolbar alloc] init];
    toolbar.delegate=self;
    CGFloat toolbarH=44;
    CGFloat toolbarW=self.view.frame.size.width;
    CGFloat toolbarX=0;
    CGFloat toolbarY=self.view.frame.size.height-toolbarH;
    toolbar.frame=CGRectMake(toolbarX, toolbarY, toolbarW, toolbarH);
    
    [self.view addSubview:toolbar];
    self.toolbar=toolbar;
}

//代理方法
-(void)composeToolbar:(MJComposeToolbar *)toolbar didClickedButton:(MJComposeToolbarBtnType)buttonType
{
    switch (buttonType) {
        case MJComposeToolbarBtnTypeCamera:
            [self openCamera];
            break;
        case MJComposeToolbarBtnTypePicture:
            [self openPhotoLibrary];
            break;
        default:
            break;
    }
}

//打开相机
-(void)openCamera
{
    UIImagePickerController *ipc=[[UIImagePickerController alloc] init];
    ipc.delegate=self;
    //数据源类型
    ipc.sourceType=UIImagePickerControllerSourceTypeCamera;
    
    [self presentViewController:ipc animated:YES completion:nil];
}

//打开相册
-(void)openPhotoLibrary
{
    UIImagePickerController *ipc=[[UIImagePickerController alloc] init];
    ipc.delegate=self;
    //数据源类型
    ipc.sourceType=UIImagePickerControllerSourceTypePhotoLibrary;
    
    [self presentViewController:ipc animated:YES completion:nil];
}

//图片选择控制器的代理
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    //NSLog(@"%@",info);
    
    //销毁picker控制器
    [picker dismissViewControllerAnimated:YES completion:nil];
    
    //设置图片
    UIImage *image=info[UIImagePickerControllerOriginalImage];
    [self.photosView addImage:image];
}

-(void)setupTextView
{
    MJTextView *textView=[[MJTextView alloc] init];
    textView.font=[UIFont systemFontOfSize:15];
    textView.frame=self.view.bounds;
    //设置垂直方向上永远可以拖拽
    textView.alwaysBounceVertical=YES;
    textView.delegate=self;
    //这句要在设置了frame之后，不然不会换行
    textView.placeholder=@"啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦啦了";
    [self.view addSubview:textView];
    self.textView=textView;
    
    //监听textView文字改变的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(textDidChange) name:UITextViewTextDidChangeNotification object:textView];
    
    //监听键盘的通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
    
}

-(void)keyboardWillHide:(NSNotification *)note
{
    NSLog(@"--%@",note.userInfo);
    
    //取出键盘的弹出时间
    CGFloat duration=[note.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    //执行动画
    [UIView animateWithDuration:duration animations:^{
        self.toolbar.transform=CGAffineTransformIdentity;
    }];
}

-(void)keyboardWillShow:(NSNotification *)note
{
    NSLog(@"%---@",note.userInfo);
    
    //取出键盘的frame
    CGRect keyboardF=[note.userInfo[UIKeyboardFrameEndUserInfoKey] CGRectValue];
    //取出键盘的弹出时间
    CGFloat duration=[note.userInfo[UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    //执行动画
    [UIView animateWithDuration:duration animations:^{
        self.toolbar.transform=CGAffineTransformMakeTranslation(0, -keyboardF.size.height);
    }];
}

-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [self.view endEditing:YES];
}

//在view完全展示后
-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
    [self.textView becomeFirstResponder];
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

-(void)textDidChange
{
    self.navigationItem.rightBarButtonItem.enabled=self.textView.text.length;
}

-(void)setupNavBar
{
    self.view.backgroundColor=[UIColor whiteColor];
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"取消" style:UIBarButtonItemStyleDone target:self action:@selector(cancel)];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithTitle:@"发送" style:UIBarButtonItemStyleDone target:self action:@selector(send)];
    self.navigationItem.rightBarButtonItem.enabled=NO;
    self.title=@"发微博";
}

-(void)cancel
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)send
{
    if (self.photosView.totalImages.count) {//有图
        [self sendWithImage];
    }else{//无图
        [self sendWithoutImage];
    }
    
}

-(void)sendWithImage
{
    //创建请求管理类
    AFHTTPRequestOperationManager *mgr=[AFHTTPRequestOperationManager manager];
    
    //封装请求参数
    NSMutableDictionary *params=[NSMutableDictionary dictionary];
    params[@"access_token"]=[MJAccountTools account].access_token;
    params[@"status"]=self.textView.text;
    
    //发生请求，带图片的发生请求与不带图片有着巨大的不同，图片要单独处理
    [mgr POST:@"https://upload.api.weibo.com/2/statuses/upload.json" parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        //在发送之前调用这个block，必须在这里说明上传哪些文件
        
        
         
        
        NSData *data=UIImageJPEGRepresentation(self.photosView.totalImages[0], 0.001);//第二个参数越大，则越清晰
        [formData appendPartWithFileData:data name:@"pic" fileName:@"" mimeType:@"image/jpeg"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"%@",[responseObject class]);
        NSLog(@"%@",responseObject);
        
        [MBProgressHUD showSuccess:@"发送成功"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        
        [MBProgressHUD showError:@"发送失败"];
    }];
    
    //关闭控制器
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)sendWithoutImage
{
    //创建请求管理类
    AFHTTPRequestOperationManager *mgr=[AFHTTPRequestOperationManager manager];
    
    //封装请求参数
    NSMutableDictionary *params=[NSMutableDictionary dictionary];
    params[@"access_token"]=[MJAccountTools account].access_token;
    params[@"status"]=self.textView.text;
    
    //发生请求
    [mgr POST:@"https://api.weibo.com/2/statuses/update.json" parameters:params success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //NSLog(@"%@",[responseObject class]);
        NSLog(@"%@",responseObject);
        
        [MBProgressHUD showSuccess:@"发送成功"];
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"%@",error);
        
        [MBProgressHUD showError:@"发送失败"];
    }];
    
    //关闭控制器
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
